# Plot Engine — Final Draft (v1)

> **Purpose:** Sustain a long-form, episodic campaign under the overplot “Survival while pursued by the Ophidarch Seraphate,” while injecting varied side‑plots that react to state (clocks, relationships, promotions).  
> **Output:** Structured episodes with setup → escalation → climax → outcomes, written as **session deltas** only.

---

## 0) Design Tenets
- **Overplot always on:** The *pursuit state machine* ticks in the background (ambush risk, recovery, resupply).
- **Rotate the spotlights:** Character Drama • Fleet Crisis • Mystery/Paranoia • External Threat • Romance • Diplomacy/Alien.
- **Clocks drive stakes:** Fuel, Food/Water, Morale, Fighter Strength, Hull Integrity. Thresholds alter episode difficulty.
- **React to the ledger:** Refugee promotions, rivalries, romances, and recent beats bias what fires next.
- **Episodes end:** Most side‑plots resolve in 1–3 sessions; unresolved threads leave a **debt, scar, or rumor**.

---

## 1) Data Files (this engine reads)
- `development/data/plot_engine_config.json` — weights, triggers, and cooldowns.
- `development/data/plot_episode_seeds.json` — canonical seeds by type.
- `development/data/overplot_survival_arc.json` — pursuit state machine, triggers, transitions.
- `development/data/fleet_clocks.json` — clock definitions, thresholds, effects.

> In Play, write outcomes into `_campaigns/<pc>/data/session_XXXX/` deltas only.

---

## 2) Episode Object (Schema)
```json
{
  "id": "fc_fuel_shortage",
  "type": "fleet_crisis",
  "title": "Tylium Dry",
  "synopsis": "A mining run failed; the fleet is running on fumes. A risky siphon op or ration riot looms.",
  "setup": ["trigger:fuel<=2", "news:civilians panic about jumps", "intel:derelict with sour fuel spotted"],
  "beats": [
    {"phase":"investigation","options":["scan derelict","negotiate siphon","calm council"]},
    {"phase":"mission","options":["siphon run through debris","escort miners","board & refit pump"]},
    {"phase":"climax","options":["storm hits mid‑transfer","pirates arrive","pump fails at 90%"]}
  ],
  "tests": ["Pilot","Interface","Authority","Tools"],
  "outcomes": {
    "success": ["fuel+2","morale+1","new contact"],
    "mixed": ["fuel+1","injury_or_damage","resentful faction"],
    "fail": ["fuel+0","riot_sparked","enemy_trace"]
  },
  "runtime_estimate": "1–2 sessions",
  "trigger_conditions": ["fuel<=2","not_on_cooldown"],
  "involved_roles": ["pilot","engineer","marines","civ_council"],
  "followups": ["myst_signal_in_the_noise","strike_on_the_line"]
}
```

---

## 3) Selection Algorithm (Summary)
1. Start with **eligible seeds** (trigger conditions true; type not cooled down).  
2. Apply **weights** from `plot_engine_config.json` (plus situation multipliers from clocks & relationships).  
3. Avoid repeating the same **type** within the cooldown window.  
4. Pick **1 primary** episode and up to **1 auxiliary** (lightweight) if allowed by `max_concurrent_sideplots`.  
5. Generate **beats** with tailored prompts and named NPCs from current context.

---

## 4) GM Running Card (Per Episode)
- **Read the Setup aloud** (as diegetic news/brief).  
- **Offer 2–3 first choices** from *investigation* beats.  
- **Escalate** to *mission* beats if chosen; otherwise push a *complication* on delay.  
- **Climax**: present 1 hard fork; set **pass/mixed/fail** consequences that touch **clocks** and **relationships**.  
- **Write deltas**; schedule **followups** or debts.

---

## 5) Integration
- **Cinematic Intro** seeds Fleet Clocks & refugee bonds → influences early weights.
- **Military Life** supplies CAP incidents and Duty seeds → can spontaneously escalate into a seed.
- **Downtime** leaks rumors → can trigger Mystery/Paranoia episodes or Romance arcs.
- **Refugee Pool** provides talent for mission roles; promotions can **resolve** or **complicate** seeds.

---

## 6) Safety & Consistency
- Never overwrite `game_files/` during Play.  
- Avoid “Cylons.” Use setting‑native equivalents (Ophidarch probes, eldritch tech, pirates, synth cults).  
- Confirm named NPCs exist or are drawn from Refugee Pool before centering them.

---

## 7) Worked Micro-Example
**Episode:** `myst_signal_in_the_noise` (mystery) → Setup: faint encoded beacon from a “lost” civilian ship.  
- **Investigation:** decryption (Interface) or canvass refugees (Social).  
- **Mission:** jump to coordinates; find the ship dark and adrift.  
- **Climax:** board and choose *rescue now* (risk) vs *tow later* (safety).  
- **Outcomes:** success → **morale+1**, gain supplies; mixed → **hull‑1**, survivor with secret; fail → trap, **ambush** triggers overplot.

