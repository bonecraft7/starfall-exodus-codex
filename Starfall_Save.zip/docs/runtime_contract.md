# Starfall Exodus — Runtime Contract (AI-facing)

- `game_files/` is canonical, read-only in play.
- New game clones seed to `_campaigns/<character>/data/newgame/<charactername>/data/`.
- All changes go into `_campaigns/<character>/data/session_XXXX/` as deltas only:
  - `beats.json`, `relationships.json`, `equipment_deltas.json`, `rank_promotions.json`, `character_sheet_delta.json`, `notes.md`.
- `SAVE STARFALL` prints a local PowerShell ritual that:
  - Backs up the prior zip to `Starfall_Save.zip.session_000X.bak`
  - Rebuilds `Starfall_Save.zip` from `game_files/`, `_campaigns/`, `tools/`, `docs/`, `play/`
  - (Optional) encrypts to `Starfall_Save.sfx.json` using `tools/Encrypt-SFX.ps1`
  - Stages changes with git; user pushes manually
- Loader (local): `tools/loader_starfall.ps1` can fetch `.zip` or `.sfx.json`, decrypt, unzip into a fresh workspace, and prepare `play/` or `development/` focus.
