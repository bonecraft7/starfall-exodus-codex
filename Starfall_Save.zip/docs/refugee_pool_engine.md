# Refugee Pool Engine — From Strangers to Shipmates (Final Draft v1)

> **Purpose:** Maintain a living **pool of refugees** and let the GM/AI **pull the right face at the right moment**—then **uplift** them into service (pilots, marines, deck, medics, intel, logistics) as plot requires.  
> **Canon:** At game start, 2–4 *female* refugees from the registry join the PC’s survival path (unknown to the PC), then all enter play as civilians. The Fleet will recruit volunteers to fill **understrength squadrons** and crews.

This engine provides **data structures**, **selection & uplift rules**, and **GM macros** that write **session deltas only**.

---

## 0) Concepts
- **Registry:** A JSON list of refugee records (id, bio, skills, flags). Source of truth.  
- **Pool:** All refugees currently available (alive, not assigned).  
- **Uplift:** Transition from `civilian` → `candidate` → `recruit` → `assigned(role)` via checks, training, and story beats.  
- **Injection:** When a scene needs “a marine/medic/tech with a face,” pick from Pool by **fit + story hooks**.

---

## 1) Files (this repo)
**Config & Rules**
- `development/data/refugees/refugee_pool_config.json` — selection weights (female‑only intro toggle), defaults.  
- `development/data/refugees/uplift_rules.json` — requirements & fast‑tracks per role.  
- `development/data/refugees/assignment_tables.json` — where people can land, with duty hooks.  
- `development/data/refugees/event_hooks.json` — when pool gets queried automatically (rescue, sabotage, romance, festival, CAP).  
- `development/data/refugees/registry_example.json` — example entries (replace with your real registry).  
- `development/data/refugees/registry_schema.json` — schema you can validate against.

**Military Integration**  
- `development/data/military/squadrons_template.json` — starting vacancies (already added).  
- `development/data/military/uplift_mappings.json` — how candidates feed squadrons/units.

**GM Aids**  
- Stubs already live in `development/templates/gm_startup_pack/` including `refugee_promotions.json`.

**Optional Tools**  
- `development/tools/validators/check_refugees.py` — validates the registry and config coherence.

---

## 2) GM Macros (human‑readable)
```
POOL.PICK(count=1, constraints=["female_only"], tags=["medic","belt_origin"]) -> [refugee_ids]
POOL.INJECT(scene="rescue", role_hint="medic", notes="patching Marine") -> delta: beats + relationships
POOL.UPLIFT(refugee_id, target="marines") -> candidate -> recruit -> assigned (with tests & timeboxes)
POOL.RETIRE(refugee_id, reason="injury|death|transfer") -> write notes + vacancies
POOL.REASSIGN(refugee_id, target="engineering") -> checks & consequences
```
> These are conceptual. In practice, you pick from the JSON and fill **session_XXXX** deltas.

---

## 3) Selection (Intro & Runtime)
- **Intro:** Draw **2–4** from Registry matching `female_only_intro=true`. Prefer **distinct skills** and **origin diversity**. Give each: a **skill tag**, a **micro‑vignette**, and a **bond +2** with PC after shared survival.  
- **Runtime Injection:** When an engine requests a face (e.g., “need a Marine with sharp eyes”), filter by `status='civilian'` or `candidate` and **fit tags** (skills/traits). Roll **Story Fit**: + origin relevance, + existing rumors, + relationship hooks.

---

## 4) Uplift Tracks
Each role defines **requirements**, **tests**, **training time**, **fast tracks**, and **story costs**. Outcomes write to `refugee_promotions.json` and `beats.json`.

Example (see JSON for all):
- **Starfighter Candidate → Pilot (Wing):** requires `Pilot >= 40` or sim eval pass. Tests: **Composure**, **ECM**, **Authority**. Training: **2 beats** minimum. Fast‑track: prior hours + crisis need (fills a vacancy). Cost: **injury risk**, **jealousy** from veterans.  
- **Marines:** `Gunnery/Strength` fitness; Tests: **Composure**, **Teamwork**. Training: **1–2 beats**.  
- **Engineering:** `Tools/Interface`; story hook: saving a deck from power cascade.  
- **Medical:** `Medicine`; oath scene at **Patchwork Clinic**.

---

## 5) Assignment & Vacancies
- Pull `military/squadrons_template.json` (wings with vacancies).  
- On successful uplift to **Pilot**, assign to squadron with the **biggest vacancy** or **story need** and log a **call‑sign** origin.  
- Non‑pilot roles slot into: **Marines Platoons**, **Deck Crews**, **Clinic**, **Logistics**. Each entry in `assignment_tables.json` includes **duty scene prompts**.

---

## 6) Relationship Integration
- New faces enter as **strangers**; run `relationships.json` deltas after key beats.  
- Use **Relationship Chaos** traits overlay if desired (impulsive, casual_ok, drama_affinity). Respect **boundaries_consent.json**.  
- Texting cadence defaults to `often`; adjust with duty schedules.

---

## 7) Notes & Safety
- No explicit sexual content. Use **fade‑to‑black**.  
- Respect **consent** and **power dynamics**; officers avoid coercion.  
- Death/retirement are story levers; prefer **scars and transfers** to cheap loss.

---

## 8) Quick How‑To
1. During intro, run `POOL.PICK(2d2, constraints=['female_only'])`.  
2. As Plot demands, run `POOL.UPLIFT(<id>, 'marines'|'engineering'|'pilot'|...)`. Log to `refugee_promotions.json`.  
3. When you need a face: `POOL.INJECT(scene='clinic_night', role_hint='medic')`. Add a beat; adjust relationships.  
4. When a slot opens in **Rook/Vesper/Mercy/Talon**: assign and note call‑sign.

