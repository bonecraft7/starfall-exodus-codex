# TNS Thronebreaker — Flag Carrier Tech Sheet (v1)

> **Shape:** a cathedral of engines and hangars. City in the belly, knives on the wings. **Voice:** gothic‑romantic; terse in combat.

**Where used:** Fleet posture, CAP planning, city scenes, fold risks, SAR lanes, downtime locations.

---

## Identity
- **Hull ID:** ship_thronebreaker  
- **Name:** TNS Thronebreaker — Flag Carrier  
- **Motto:** *Hold the lanterns.*  
- **Role:** flagship, refugee host, air‑wing cradle, fold‑capable ark

---

## Dimensions & Capacities (operational)
- **Length:** ~1,480 m · **Beam:** ~420 m · **Decks:** 38  
- **Crew:** ~5,500 · **Air‑wing pilots:** 48 (4 squadrons × 12) · **Air‑wing support:** ~600  
- **Refugee capacity (civil block):** 38,000 safe · **Life‑support spike ceiling:** 50,000 (24h max)  
- **Bays:** A (forward), B (starboard), C (reserve/SAR). See `data/ship/thronebreaker_hangars.json`.

---

## Drives & the Fold
- **Propulsion:** tri‑vector fusion spindles with gimbaled verniers.  
- **Fold Engine:** *Cathedral Drive* (eldritch). Choir‑assisted timing; calculus engraved in moving plates.  
- **Charge:** ~6 hours between jumps · **Recovery:** ~12 hours.  
- **Known Costs:** ship‑wide fatigue +1; sensitive crew stress +1; minor gear faults likely.  
- **Failure Modes:** timing drift (lane shear), tinnitus bell, rare **attention** event.  
- **Ritual Rails:** no gore; make it numinous and a little wrong.

---

## Posture Protocols
- **WHITE:** calm lanes — CAP 1 flight (4). City open.  
- **AMBER:** uneasy — CAP 1 flight + Ready 1; curfew soft.  
- **RED:** contact likely — CAP 2 flights (8), scramble ready; curfew hard; blast doors active.  
- **SABLE:** fold prep or eldritch operations — quiet lights, choir net active; CAP 1 flight + ECM hymn on call.

---

## SAR & Traffic Lanes
- **Mercy Lane:** medical shuttle corridor, under dorsal spine.  
- **Lantern Mile:** bulk civilian traffic; staggered approach rings.  
- **Blackwater:** SAR strip behind the wake; tug priority.  
- **Picket Vectors:** A/B/C cones for fighters; do not cross Lantern Mile at speed.

---

## City in the Belly (civil block)
A neon thicket stitched into cargo caverns. *Neo‑Tokyo* vibes: AR lanterns, mile‑long markets, steam and string lights.  
- **City Name:** **New Kintsugi**  
- **Interim Mayor:** **Yuna Kade** (appointed by civilian council; peer of the XO)  
- **Districts:** Lantern Mile Market · Rain Alley · Glass Garden · Hearthlight Square · Night Dock · Choir Steps  
- **Sample Venues:**  
  - **Lantern Exchange** (bazaar spine) — barter & newswall.  
  - **The Singularity** (club) — bass like weather; rumors trade here.  
  - **Red Silk** (revue/strip) — adult‑only entertainment; consensual, licensed, security present.  
  - **Hearthlight Kitchens** — big‑pot food, volunteer boards.  
  - **Patchwork Clinic** — low‑resource med; triage hub.  
  - **Quiet Rooms** — grief space; chaplain net.  
- **Perimeters:** 3 military rings; visa checks; amber curfew on RED.

**Consent & Tone:** Adults only; fade‑to‑black; the city is a sanctuary first.

---

## Departments & Hotlines
- **Air Wing** (CAG): squadrons Wolf, Viper, Jackal, Raven.  
- **Deck Division** (Chief): launches, catches, repairs.  
- **Engineering:** drives, fold plates, habitat.  
- **Medical:** main med, Patchwork overflow.  
- **Security/MP:** city perimeter, visa scans, curfews.  
- **Eldritch Division:** hymnological lab, pattern scry, taboos posted.

---

## Incident Hooks (roll or pick)
- Hangar heat spike; ECM hymn hums wrong.  
- Refugee market riot over counterfeit visas.  
- Fold plate sings a note no one knows.  
- SAR tug brings back something attached.  
- Deck chief calls for a volunteer pilot for a cursed crate.  
- Mayor Kade requests escort to inspect Hearthlight generators.

---

## Files
- **Data sheet:** `development/data/ship/thronebreaker.json`  
- **Hangars:** `development/data/ship/thronebreaker_hangars.json` (bays & squadron placement)  
- **City locations:** see `thronebreaker.json :: city.locations` (growing list)

Hold the lanterns. Count the living. Move.
