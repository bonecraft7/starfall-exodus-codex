# GM Runbook — Refugee Run (Extended)

**Load:** Use `play/entrypoints/play_jin_default.json`. Engines that support `play_start_override` will route 'Load Jin' automatically to this module’s entry_scene.

**Clocks:**
- Hunger (3), Exhaustion (4), Panic (3).
Advance clocks at each scene; allow trade-offs (food vs time; rest vs exposure).

**Near-Death (Act IV):**
- Force a binary: Fight a single enemy or execute a decoy. Award 1 Scar Boon.

**Completion:**
- Set Prelude_RefugeeRun_Complete and Rescued_By_Thronebreaker.
- Carry Clique Bond Meter into Act I of the main campaign.

## Bespoke Scar Boons
- Paula — Fracture Kiss: +1 die once/session on shoves, grapples, bracing.
- Julia — Quiet Pulse: auto-succeed simple tech stabilize/jam once/session.
- Chihiro — Edge of Silence: ignore first Panic escalation when near Jin.
- Élise — Stitch of Dawn: convert 1 Harm → 1 Exhaustion once/session.

## Horror Cut Notes
- Always begin at `prologue_bar/00_bar_normalcy` with light flirt options.
- Randomize the remaining three survivor join scenes per `meeting_order_rules.json`.
- Use nameless NPCs for attrition; escalate Hide-and-Seek tension.
- Award bespoke Scar Boons during Act IV per survivor JSON.
