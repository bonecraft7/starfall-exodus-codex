# At‑the‑Table Quickref (PbtA 2d6)
- Roll **2d6 + Axis** (Ops / Heart / Weird).
  - **10+**: clean success; pick 1 bonus if offered.
  - **7–9**: mixed; success with cost, or success/choice.
  - **6‑**: miss; GM advances a clock or introduces a new danger.
- **Advantage/Disadvantage**: roll 3d6, take best/worst 2.
- **Clocks**: Pursuit, Fleet Morale, City Stability, Engineering Integrity, Diplomacy. Ticks = pressure.
- **Consent & Tone**: R‑rated in **scale**; fade‑to‑black for intimacy. Player can hard‑no any beat.