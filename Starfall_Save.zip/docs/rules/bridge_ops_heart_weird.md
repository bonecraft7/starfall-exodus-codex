# Dice Bridge — mapping your engine → Ops / Heart / Weird (v1)

> **What this is:** A thin, explicit adapter so *any* dice/conflict engine in `game_files/system/engines` can resolve **Tests** on three axes: **Ops** (doing the thing), **Heart** (people & nerves), **Weird** (eldritch & perception).  
> **What it is not:** A replacement for your engine. We normalize your engine’s outcome into **pass / mixed / fail**.

---

## 0) The two-stage model
1. **Translate**: your engine produces a raw outcome (e.g., `roll_total`, `successes`, `dos`, `2d6_total`, `4dF_total`). A **profile** under `tools/bridges/profiles/*.json` translates that into either:
   - a **normalized score** `S` in **[-1, +1]**, or
   - a **categorical** result (pass/mixed/fail).

2. **Bucket**: we apply **difficulty** and **edge** to push the result, then bucket to **pass / mixed / fail** per `data/plot/tests_bridge.json`.

This is deterministic over your inputs; no new dice are invented.

---

## 1) Difficulty & Edge
- Difficulties: **trivial / easy / standard / hard / extreme** → implemented as shifts to DC or to normalized `S`.  
- Edge states: **advantage** (+S) and **disadvantage** (−S) *after* translation. They represent positioning, not extra dice (you can still roll advantage inside your engine; the Bridge only sees your final roll).

---

## 2) Profiles shipped
- **d20 / target-number** — works for d20 and d100 TN systems.  
- **PbtA 2d6** — 10+ / 7–9 / ≤6.  
- **Dice pool** — compare counted **successes** vs **required**.  
- **FATE 4dF** — compare total + stat vs difficulty.

Pick one, or clone to define your exact engine (see `adapter_spec` inside each).

---

## 3) Axis mapping (skills → axes)
Use Ops/Heart/Weird **as intent**, not stats. An Ops test can use **Pilot** or **Tools** depending on fiction. The mapping lives in `data/plot/tests_axis_map.json` and is purely advisory for the AI’s prompts.

---

## 4) Using from play
1. The scene says: `TEST: Ops (Standard) + Heart (Easy)` (maybe Weird too).  
2. Roll/resolve using your engine as usual.  
3. Feed the resolved values to the Bridge profile (see `bridge_eval.py` examples).  
4. Read back **pass / mixed / fail** per axis and apply **consequence bundles**.

---

## 5) Safety dials
- **Mixed** should be frequent and interesting; avoid whiff-fest.  
- Keep **fail** survivable unless the player invites harder edges.

---

## 6) Where things live
- Config: `development/data/plot/tests_bridge.json`  
- Axis map: `development/data/plot/tests_axis_map.json`  
- Profiles: `development/tools/bridges/profiles/*.json`  
- CLI helper: `development/tools/bridges/bridge_eval.py`
