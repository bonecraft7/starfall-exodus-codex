# Celebrity Recognition — Dice Hook (d6 pips)

**Purpose:** lightweight, cinematic way to decide if someone recognizes a celebrity NPC in a scene.

- Roll **1d6** and compare to **pips** (0–5). If `roll ≤ pips`, someone recognizes them.
- **Base pips** by scene:
  - `quiet`: 0 (rare)
  - `crowded`: 1
  - `packed`: 2
  - `online`: 2
- Apply **modifiers** (±1 pips each) from the celebrity’s config, then clamp 0–5.

### Chihiro (Neon Onryō) modifiers
`hair_visible` +1 • `stage_makeup` +1 • `spiked_cap` +1 • `hood` −1 • `sunglasses` −1 • `mask` −1 • `post_disaster_chaos` −1 • `region_jp_diaspora` +1 • `alt_scene` +1 • `burberry_check_pop` +1

### Escalation
If recognized, use the **roll** to pick a cue: whisper → photo → social ping → security → mini‑mob → stalker thread.

### CLI
```bash
# Basic crowded scene in the Mile market
python tools/plot/celebrity_recognition.py --npc Chihiro_Watanabe --scene crowded --mods hair_visible alt_scene --cover sunglasses --explain

# Jam‑packed club, stage makeup on, no cover; set seed for reproducibility
python tools/plot/celebrity_recognition.py --npc Chihiro_Watanabe --scene packed --mods hair_visible stage_makeup spiked_cap --seed 42 --explain

# Quiet corridor with hood and shades
python tools/plot/celebrity_recognition.py --npc Chihiro_Watanabe --scene quiet --cover hood sunglasses --explain
```
**Integrate:** The GM can call this once per crowd beat or once per room change.