# Episode Starters (v1)
Drop-in outlines to kick an evening fast. Use with Plot Engine 1.0; swap missions to taste.
- `ep-0001-social` — Lantern Mile drama before a convoy.
- `ep-0002-military` — Ambush near Blackwater; SAR choice.
- `ep-0003-diplomacy` — Courtesy escort with Ghost Net whisper.