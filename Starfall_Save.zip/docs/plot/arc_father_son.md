# Father & Son Core Arc — Jin and Daniel Kang (v1)

**Vibe:** Apollo/Adama gravity. Pride weaponized as armor; reunion as oxygen.

## Truth table
- **Daniel** is *alive*, posted away from the main deck at opener, and **believes Jin is KIA** due to a bad report 5 years ago.
- **Jin** resents Daniel’s absence post-divorce, but flies like him.

## Phases (drop these as subplots across early episodes)
1. **Echo** — a deck chief or Raven rookie notes Jin’s *pause* on Guard: “You sound like… no, never mind.”
2. **Rumor** — SAR finds a sealed letter addressed to *J. Kang* among Ghost keepsakes.
3. **Near Miss** — cross‑ship comms glitch: Daniel hears *“Grey”* and freezes; doesn’t connect the name.
4. **Reveal** — hangar or medbay scene after a hard op. One word: “Son.” (Adama/Apollo cadence—no speeches, just air.)
5. **Fallout** — anger + relief. Who left whom? Why the bad report? Set a **debt** and a **promise**.
6. **New Order** — Daniel accepts the call sign **Ripper** after Jin earns it; Ghost name lives in deeds, not nostalgia.

## How to trigger
- Add `bias: father_son` to the Plot Engine for the first 3–6 sessions.
- Allow *any* clean/mixed/miss to advance the arc; don’t stall on success.

## Consent & Heat
This is family grief. Keep it raw without cruelty. Let them fail with love.