# Plot Engine — Episodes, Missions, Consequences (Finish Pass v1)

> **Contract:** One overplot forever: *Humanity survives while the Ophidarch Seraphate hunts.* Around it, the game spins **episodes** (6–8 beats) that braid **military ops**, **fleet crises**, **mystery/eldritch**, **diplomacy/alien**, and **social/romance** threads. This engine tells the AI *what to pick next* and *how to resolve it* with pass/mixed/fail consequences that matter.

**Integrates with:** Cinematic Intro • Refugee Pool • Squadron Ops • Military Life • Downtime • Relationships Chaos v2 • Alien Encounters • City (New Arcadia).

---

## 0) Episode Shape
- **Lengths:** *Mini* (3–5 beats), *Standard* (6–8), *Double* (9–12).  
- **Weave:** Each episode chooses **1 Major** thread + **1–2 Minor** threads. Major drives pacing; Minors provide heart or weird.  
- **Beats:** `Hook → Complication → Midpoint Choice → Escalation → Crisis → Resolution → Stinger` (prune/extend as length demands).

Data: `data/plot/episode_pacing.json`

---

## 1) Mission Types
Canonical set with objectives, test axes, and baseline risks. Used by the AI to frame scenes and pick consequences.

Data: `data/plot/mission_types.json`, variations in `mission_variations.json`.

---

## 2) Generators & Seeds
Pick a **Major** from `arc_generators.json` by category (military, crisis, mystery, eldritch, diplomacy, social/romance, survival/exploration, ethics/politics, flashback/history). Each seed lists openers, choices, and outcomes. Never use “Cylons.”

---

## 3) Tests & Outcomes
Every mission resolves along **two axes** (Ops & Heart), with an optional **Weird** axis when the eldritch breathes. Roll tests or narrate choices against `data/plot/tests.json`. Map results into **consequence bundles** from `consequence_tables.json` (morale, trust clocks, city clocks, casualties, gear damage, relationship shifts).

---

## 4) Pursuit & Pressure
Keep a **Pursuit Clock** (0–6) in `overplot_pursuit.json`. It ticks on noise, time, or hubris. At thresholds, schedule **Ophidarch events** (shadowers, leakers, raids). Use posture codes (WHITE/AMBER/RED/SABLE) to squeeze the episode.

---

## 5) Episode Cards & Logging
Use the template in `templates/plot/episode_outline.json` to sketch the Major/Minors, clocks, and intended tests. After each beat, propose deltas for `beats.json`, `relationships.json`, `character_sheet_delta.json`, `equipment_deltas.json`, and any `refugee_promotions.json` events.

---

## 6) GM Macros (conceptual)
```
PLOT.EPISODE(len="standard", major="military_ops", minors=["social","mystery"])
PLOT.MISSION(type="escort_convoy", variation="ambush_lane")
PLOT.TEST(axes=["Ops","Heart","Weird?"]) -> success|mixed|fail per axis
PLOT.CONSEQUENCE(bundle_id) -> deltas (morale/trust/city/gear/relationships)
PLOT.PURSUIT(tick=+1|−1, cause="noise|time|hubris") -> schedule event if threshold
PLOT.THREAD(seed_id) -> beats prompt
```
Write **session deltas only**. Keep failures survivable unless the player invites harder edges.

---

## 7) Safety
R‑rated in **scale**, not gore. Consent & boundaries on; intimacy **fade‑to‑black**. Political/ethical dilemmas are about **choices and costs**, not slurs.

The fleet moves. The sky listens. Make it cost, and make it sing.
