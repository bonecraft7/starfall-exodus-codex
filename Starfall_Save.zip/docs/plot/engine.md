# Plot Engine 1.0 — Episode Driver (v1)

**Purpose.** Keep long‑form play moving without menus. The engine watches **clocks** and serves **episode skeletons** built from **mission types**, then sprinkles **CAP Chatter** by phase.

**Core pieces**
- **Mission Types** — reusable frames (CAP, Escort, Strike, SAR, Recon, Diplomacy Corridor, Eldritch Escort, Ambush Response, Market Crisis).
- **Episode Arcs** — buckets that mix mission types over 1–3 sessions (Social, Military, Eldritch, Diplomacy).
- **Clocks** — `fleet_morale`, `city_stability`, `engineering_integrity` (+ existing `pursuit`, `diplomacy_*`).
- **Consequence Bundles** — what a clean/mixed/miss does to clocks, resources, relationships.
- **CAP Chatter Integration** — per‑phase radio color draws from `data/military/cap_chatter.json`.

**Flow at the table**
1. Pick an **Arc** (or let the picker choose by hottest clock).
2. Picker selects a **Mission Type** and outputs a 5‑phase skeleton: *Launch → Chatter → Merge → Break → RTB* (plus emergency/weird as needed).
3. During each phase, pull 1–2 **Chatter lines** from the relevant bucket (placeholders auto‑filled).
4. Roll moves. On resolution, apply a **Consequence Bundle**. Tick the clocks.

**Safety & Tone** — gothic‑cinematic, terse in combat; R‑rated in scale, not gore. Consent gates always honored.
