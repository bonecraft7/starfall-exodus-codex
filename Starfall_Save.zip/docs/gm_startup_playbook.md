# GM Startup Playbook — One‑Button Opener (Final Draft v1)

> **Contract:** Every new campaign begins with the **Cinematic Intro Pipeline** → recruits **2–4 Refugees** → **Kuiper Rendezvous** → **Thronebreaker Fold**.  
> **Use:** Run this card verbatim. Where a decision appears, pick or roll. Write **deltas only** to the current session.

---

## Quick Card (TL;DR)
1. **Locale & Mood** → pick from `startup_config.json` or roll. Roleplay 2–4 minutes of ordinary life.  
2. **Astrophobia Cue** → trigger the sky‑breaking event; call **Composure**.  
3. **Survival Challenges ×3** → mix hazard/social/tech; insert **Refugee #1** at challenge 2, **#2–#4** at challenge 3.  
4. **Extraction** → vector to safety (shuttle/tug/pod/lifter/cruiseliner). On failure, mark scars/debts.  
5. **Kuiper Muster** → set Fleet clocks per config; announce escort losses.  
6. **Fold** → narrate the Eldritch engine; hand off to **Intake & Assignment**.

*Everything you need is pre‑staged in this pack: prompts, tables, and delta templates.*

---

## One‑Button Macro (Human‑Readable)
- **RUN:** `Intro(locale=random, refugees=2d2, tone="cinematic", scars_allowed=true)`  
- **RUN:** `Survival(challenges=3, mix="hazard+social+tech", insert_refugees="2|3")`  
- **RUN:** `Extraction(vector=roll)`  
- **SET:** `FleetClocks(startup_config.json)`  
- **SET:** `FleetComposition(kuiper_muster_template.json)`  
- **WRITE:** `session_XXXX/*.json` using **Logging Stubs** (see below).

> These are conceptual macros. In practice, use the **Logging Stubs** JSON below and fill them as you play.

---

## Prompts & Tables
Use the fully drafted systems:
- **Cinematic Intro Pipeline** → `development/docs/cinematic_intro_pipeline.md`  
- **Refugee Pool Engine** → `development/docs/refugee_pool_engine.md`  
- **Military Life Loop** → CAP/Duty hooks next session  
- **Downtime Engine** → offer after Fold if safe  
- **Solar Collapse Chronicle** → grab vignettes for color

Shortcut lists are duplicated in `startup_prompts.json` for quick reference.

---

## Logging Stubs (Copy into your session)
Place these in `_campaigns/<pc>/data/session_XXXX/` and edit as you play:

### `beats.json`
```json
{
  "session_id": "session_XXXX",
  "created_utc": "NOW_UTC",
  "beats": [
    {"id":"b0_vignette","title":"Ordinary Life","notes":"three sensory details; petty desire"},
    {"id":"b1_astrophobia","title":"The Sky Breaks","notes":"cue chosen; Composure result"},
    {"id":"b2_survival_1","title":"Challenge 1","notes":"type/test/outcome"},
    {"id":"b3_survival_2","title":"Challenge 2 + Refugee #1","notes":"meet-cute or crisis"},
    {"id":"b4_survival_3","title":"Challenge 3 + Refugee #2–#4","notes":"bond/complication"},
    {"id":"b5_extraction","title":"Extraction Vector","notes":"vector + cost"},
    {"id":"b6_kuiper","title":"Rendezvous at Kuiper","notes":"fleet first impressions"},
    {"id":"b7_fold","title":"Eldritch Fold","notes":"sensory; prayers; promises"}
  ]
}
```

### `relationships.json`
```json
{
  "session_id":"session_XXXX",
  "entries":[
    {"npc_id":"REFUGEE_1","delta":6,"state_hint":"acquaintance -> friendly","note":"shared danger"},
    {"npc_id":"REFUGEE_2","delta":3,"state_hint":"stranger -> acquaintance","note":"rescued sibling"},
    {"npc_id":"NPC_RIVAL?","delta":-2,"note":"argument during panic"}
  ]
}
```

### `equipment_deltas.json`
```json
{
  "session_id":"session_XXXX",
  "items":[
    {"id":"lost_backpack","action":"lost","note":"crowd crush"},
    {"id":"found_token","action":"found","note":"lantern market charm"}
  ]
}
```

### `character_sheet_delta.json`
```json
{
  "session_id":"session_XXXX",
  "effects":[
    {"type":"stress","value":1,"note":"sirens + stampede"},
    {"type":"injury_minor","value":1,"note":"smoke inhalation"}
  ]
}
```

### `refugee_promotions.json` (optional at start)
```json
{
  "session_id":"session_XXXX",
  "events":[
    {"refugee_id":"REFUGEE_1","action":"summon","reason":"met in tram jam"}
  ]
}
```

### `notes.md`
Start with: first impressions of each refugee, one ship name that stuck, one vow you made before the Fold.

---

## Startup Clocks & Fleet
- Initialize clocks using `development/data/fleet_clocks.json` values unless your campaign dictates otherwise.  
- Instantiate composition using `development/data/kuiper_muster_template.json`.

---

## Safety Rails
- Respect `boundaries_consent.json`.  
- Fade‑to‑black for intimacy.  
- Invasive horror stays R‑rated: describe impact, not explicit gore.

---

## Hand‑Off
After Fold, run **Intake & Assignment** (bureaucracy + first volunteer call). Then spin either **CAP Day One** or a low‑stakes **Downtime Window** to breathe.

