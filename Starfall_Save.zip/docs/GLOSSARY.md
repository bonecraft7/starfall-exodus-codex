# Glossary
- **CAP** — Combat Air Patrol; fighters keeping lanterns safe.
- **Cathedral Drive** — fold engine; numinous, risky, never scanned.
- **Lanterns** — refugee convoys; also the visible wake lights.
- **New Kintsugi** — refugee city inside Thronebreaker.
- **SABLE** — posture for fold/eldritch ops; quiet lights, choir net.
- **Ghost Net** — enemy comms mirage that repeats yesterday.
- **Gravemill** — enemy orbit‑shear towers; timing goes wrong.
- **Black Ladder** — kinetic 'steps' walking across a world.
- **Weird** — uncanny axis; choir, hymns, patterns.