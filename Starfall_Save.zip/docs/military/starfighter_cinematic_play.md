# Starfighter Cinematic Play
- **Frames**: Launch → Chatter → Merge → Break → RTB.
- **CAP**: 4 fighters up in WHITE/AMBER; 8 in RED; ECM hymn on SABLE.
- **Cinematic Moves**: Barrel‑write, Knife‑edge, Lantern Screen, Blackwater SAR.
- **Bridge**: You may swap a single signature beat to d20 Alt Ops, then return to PbtA.