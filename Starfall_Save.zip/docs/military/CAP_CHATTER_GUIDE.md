# CAP Chatter — Color Pack (v1)

Use these lines to paint the sky during CAP phases. Keep it tight; let silence talk too.

## How to use
- Pick a **bucket** by phase: `launch`, `chatter`, `merge`, `break`, `rtb`. Optional: `emergency`, `weird`, `sar`, `alien`, `deck`.
- Substitute placeholders in `{curly}` with fitting values:
  - `{callsign}` — e.g., *Raven Two*, *Wolf One*
  - `{wing}` — *Wolf*, *Viper*, *Jackal*, *Raven*
  - `{element}` — *Lead/Two/Three/Four*
  - `{bearing}` — three-digit style: *0-9-0*
  - `{alt}` — tens of thousands: *two-five*
  - `{seconds}` — *20/30/45/60*
  - `{channel}` — *Guard/Pri-Fly/Ops*
  - `{fuel_state}` — *green/amber/bingo*
  - `{vector}` — *A-cone/B-cone/C-cone/Blackwater stair*

**Tone:** gothic-cinematic, terse in combat. No slurs; fear by scale, not cruelty.

## Example
- Phase **merge** → “Bandits angels {alt}, hot from {bearing}. {wing}, bracket.”  
  → “Bandits angels **two-five**, hot from **2-7-0**. **Wolf**, bracket.”

Keep Lantern Mile safe. Let the radios breathe.
