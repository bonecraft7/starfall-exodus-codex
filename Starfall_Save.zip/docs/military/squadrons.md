# Starfighter Squadrons — Thronebreaker Air Wing (v1)

> **Intent:** Four squadrons exist, but **Wolf**, **Viper**, and **Jackal** begin **gutted** by early‑war losses; **Raven** is the most intact. Vacancies will be filled by **Refugee Pool uplift** and transfers during play.

**Files:**  
- `development/data/military/squadrons.json` — roster & structure  
- `development/data/military/vacancy_fill_rules.json` — how the AI fills seats  
- `development/data/ship/thronebreaker_hangars.json` — bay/flight parking

**Structure:** capacity **12** per squadron (Alpha 1–4, Bravo 5–8, Charlie 9–12).

**Player seat:** Your PC will be slotted into a vacant position by the AI during intake/eval.

**Callsign cultures (vibe):**
- **Wolf** — aggressive hunters; dark humor; fly tight. *(Gutted)*
- **Viper** — precision & ECM discipline; clipped comms. *(Gutted)*
- **Jackal** — opportunists & SAR daring; laugh in static. *(Gutted)*
- **Raven** — steady guardians; ritualistic pre‑flight. *(Light losses)*

**Vacancy fill heuristic:** prioritize **flight integrity** (keep Alpha flight viable), then spread skill coverage, then personal drama hooks.
