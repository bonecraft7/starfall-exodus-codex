# Jackal Squadron — Recon / SAR / ECM (Quickref)

**Role:** **Eyes & lanterns.** Recon the lanes, pull our people home, sing the ECM hymn.  
**Roster:** *Gutted after the Fall.* Choir-trained welcome.  
**Home:** Reserve bay; jumps between **Blackwater** and pickets.

## Doctrine
- Lanterns first. A living pilot is worth ten kills.
- **ECM hymn** on SABLE cue; Weird calls when patterns hum.
- Mark wreckage; seed tugs; write names.

### CAP Matrix by Posture
- **WHITE** — 1 flight (4) on station; 1 flight Ready in 10.
- **AMBER** — 1 flight (4) on station; 1 flight Ready in 5; deck at half-crew.
- **RED** — 2 flights (8) on station; 1 flight Scramble in 2; blast doors armed.
- **SABLE** — 1 flight (4) on station; ECM hymn on a hair trigger; quiet lights.



### Scramble Flow (deck → space, 120s target on RED)
1. **Bell** → status RED; helmets on; last-check fuel/ordnance.
2. **Deck Chief GREEN** → taxi; follow marshaller wands; no chatter.
3. **Cat Stroke / Throw** → HUD alive; DRADIS check; wing join at 2km.
4. **Fence In** → weapons **COLD** until CAG clears **HOT**.
5. **On Station** → report vector and fuel state; settle into CAP pattern.



### Emergencies (brevity)
- **BINGO** (fuel low) → RTB route; hand CAP to next flight.
- **NOGO** (systems fault) → Abort; orbit Blackwater; tug if needed.
- **PUNCHOUT** (ejection) → Beacon on; Jackal SAR vectoring.
- **ANGEL DOWN** (lost craft) → Raven takes cover; Wolf screens.



### Dice Bridge (PbtA axes)
- **Ops** — flying, fighting, fixing under fire.
- **Heart** — read a wingmate, calm a crowd, keep them together.
- **Weird** — choir hums, ECM hymn, the feeling before the hit.
> Advantage/Disadvantage: roll 3d6, take best/worst 2.

### SAR Pattern (Blackwater)
- Spiral out from beacon; tag debris; green smoke on survivors.
- Handoff to tug; **do not** chase beyond cone without CAG.
