# Squadron Ops — Quick Summary

**WOLF** — Interceptors & screen.  
**VIPER** — Strike & escort.  
**JACKAL** — Recon / SAR / ECM hymn.  
**RAVEN** — Composite; trains strays; player default.

See per‑squad quickrefs for CAP matrix, scramble flow, and emergency brevity.  
*Color pack pending:* CAP radio chatter & deck slang (`data/military/cap_chatter.json` stub).
