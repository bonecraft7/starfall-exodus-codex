# Viper Squadron — Strike / Escort (Quickref)

**Role:** **Strike** packages and **bomber escort**; knives for problems too big for talk.  
**Roster:** *Gutted after the Fall.* Heavy ordnance scarce.  
**Home:** Starboard rotation; launches in pairs with Raven or Wolf cover.

## Doctrine
- Keep **civ lane clean**; strike only with corridor clearance.
- **Time on Target** wins episodes; don’t dogfight unless you must.
- If CAP collapses, become CAP. If CAP holds, **finish the job**.

### CAP Matrix by Posture
- **WHITE** — 1 flight (4) on station; 1 flight Ready in 10.
- **AMBER** — 1 flight (4) on station; 1 flight Ready in 5; deck at half-crew.
- **RED** — 2 flights (8) on station; 1 flight Scramble in 2; blast doors armed.
- **SABLE** — 1 flight (4) on station; ECM hymn on a hair trigger; quiet lights.



### Scramble Flow (deck → space, 120s target on RED)
1. **Bell** → status RED; helmets on; last-check fuel/ordnance.
2. **Deck Chief GREEN** → taxi; follow marshaller wands; no chatter.
3. **Cat Stroke / Throw** → HUD alive; DRADIS check; wing join at 2km.
4. **Fence In** → weapons **COLD** until CAG clears **HOT**.
5. **On Station** → report vector and fuel state; settle into CAP pattern.



### Emergencies (brevity)
- **BINGO** (fuel low) → RTB route; hand CAP to next flight.
- **NOGO** (systems fault) → Abort; orbit Blackwater; tug if needed.
- **PUNCHOUT** (ejection) → Beacon on; Jackal SAR vectoring.
- **ANGEL DOWN** (lost craft) → Raven takes cover; Wolf screens.



### Dice Bridge (PbtA axes)
- **Ops** — flying, fighting, fixing under fire.
- **Heart** — read a wingmate, calm a crowd, keep them together.
- **Weird** — choir hums, ECM hymn, the feeling before the hit.
> Advantage/Disadvantage: roll 3d6, take best/worst 2.

### Loadouts (guidance)
- **RED short**: light missiles + ECM sled.  
- **RED long**: heavy pair + drop tank (fuel x1.2).  
- **SABLE**: cold rails; ride the hymn; preserve signature.
