# Refugee → Service Pipeline (v1)

**Aim.** Promote refugees into service *in play* without breaking immersion. Prioritize **your custom refugees**, fill gutted squadrons (Wolf, Viper, Jackal) first, Raven as overflow. Produce **delta JSON** that can be written to the current session folder.

**Where it plugs in**
- Draw candidates from `game_files/data/refugees/registry_merged.json` (your entries win).
- Check squadron capacity from `game_files/data/military/squadrons.json` if present, otherwise use defaults: see `development/data/military/squadron_capacity_defaults.json`.
- Training path from `development/data/military/pilot_training_tracks.json`.
- Vacancy priority from `development/data/military/vacancy_fill_rules.json`.

**Officer note.** Pilot volunteers commission as officers by default (rank: **Ensign**). Adjust in session if desired.

---

## Pipeline Steps (GM or tool)
1. **Pick candidate** (ID or name) from the merged registry; confirm `status: refugee` and `gender: f` if using intro rule.
2. **Eligibility** — confirm `eligible_branches` includes the target (e.g., `"pilot"`). If not, allow override with a cost.
3. **Generate Service Record**
   - `service_id` (stable slug), `rank`, `branch`, `track: pilot`, `training_state: trainee`.
4. **Assign Squadron**
   - Use `vacancy_fill_rules.json` (Pilot: **Wolf → Viper → Jackal → Raven**) unless a `--squadron` override is given.
   - If no vacancy in any, assign **Raven** or leave as **Training Pool**.
5. **Write Delta** (for session `session_XXXX`):
   - `assignments`: add to squadron roster.
   - `service_records`: new record keyed by `refugee_id`.
   - Optional: `relationships_delta` seeds.

**Tooling** — use `tools/military/uplift_refugee.py` to do steps 1–5 and **print** the delta JSON. Pipe it into a session file.

---

## CLI Examples
- Dry run (choose squadron by rules, don’t write):
  ```bash
  python tools/military/uplift_refugee.py --devroot development --ref "ref_jane_doe_tycho" --branch pilot --dry
  ```
- Force assignment to **Wolf**:
  ```bash
  python tools/military/uplift_refugee.py --devroot development --ref "ref_jane_doe_tycho" --branch pilot --squadron Wolf --dry
  ```
- Write delta to current session folder:
  ```bash
  python tools/military/uplift_refugee.py --devroot development --ref "ref_jane_doe_tycho" --branch pilot --out "_campaigns/Locke/data/session_0007/assignments_delta.json"
  ```

**Safety** — Consent gates still apply. Spotlight is shared. Record scars and debts honestly.
