# Design Specs (No Build)
This directory contains **design-only** contracts for future implementation:
- Conflict engines (scene types, mixed-result triggers, ending palettes)
- Character-creation desires (identity, outfits, underwear styles, intimacy rules)
- Terran Last Diaspora culture config (origins, accents, finite name pools)

**Do not** implement mechanics until Locke gives the word.