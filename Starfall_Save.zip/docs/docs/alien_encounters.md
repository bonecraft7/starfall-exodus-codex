# Alien Encounter Framework (Skeleton)

Rare, arc-level first-contact scaffolding with defensive posture.

## Arcs
- Aid offers, pirates/scavengers, cultural exchange, misunderstandings

## Protocol
- Scramble posture, comms, trust thresholds
