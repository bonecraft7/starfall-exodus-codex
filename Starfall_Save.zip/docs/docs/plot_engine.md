# Plot Engine / Episode Seeds (Skeleton)

Episodic arcs with setup → escalation → climax → outcomes.

## Types
- Character Drama, Fleet Crisis, Mystery/Paranoia, External Threat, Romance

## Data Format
```json
{{"id":"","type":"","setup":[],"beats":[],"climax":[],"outcomes":[]}}
```
