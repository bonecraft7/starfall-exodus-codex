# World Consequence Bindings — System Doc (Skeleton)

> **Source JSON:** `game_files/system/engines/world/world_consequence_bindings.json`  
> **Intended final location:** `docs/systems/world_consequence_bindings.md`

## Overview
Brief description of what this engine does and when it is invoked by the AI GM.

## Data Model
- Key fields from the JSON and what they mean.
- Valid ranges, enums, references to other files.

## GM Usage (Human & AI)
- When to call this engine during play.
- Inputs the GM provides (prompts/flags).
- Expected outputs: narrative beats, rolls, state deltas.

## Examples
- Example input → output.
- Edge cases and failure/complication branches.

## Integration
- Related systems (dice, encounters, messaging, relationship).

## TODO
- [ ] Verify JSON fields & add schema snippet
- [ ] Add 2–3 worked examples
- [ ] Cross-link to plot engine and downtime
