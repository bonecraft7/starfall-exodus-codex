# Slice‑of‑Life Downtime Engine — Final Draft (v1)

> **Scope:** Generates rich off‑duty scenes between missions: rest, romance, repairs, politics, and petty joys aboard the fleet.  
> **Tone:** Human-scale color under cosmic pressure. Small choices ripple into bonds, rumors, and future arcs.

---

## 0) Design Goals
- **Always character-forward.** Every downtime scene exposes a habit, secret, or desire.
- **Variety without bloat.** Curated menus + random spice; no two “days off” feel the same.
- **Hooks everywhere.** Each outcome should seed a lead: a text thread, a favor, a debt, a clue.
- **Delta-only.** In Play, write session deltas only; never mutate `game_files/`.

---

## 1) When to Offer Downtime
Offer a **Downtime Window** when any is true:
- After a major mission/episode resolution.
- After **2–3 routine days** without cinematic escalation.
- When **Stress/Fatigue** exceeds soft caps.
- When the player explicitly calls for time off.

**Length:** default **1 block** (~2–4 in‑scene beats). Optional multi-block leave (shore leave) on safe jumps.

---

## 2) Menu Generator (Flow)
1. Collect **Context** (last mission tag, current Fleet Clocks, active relationships, injuries).  
2. Compile **Shortlist**: 5 items from categories below (weighted by context).  
3. Present as **choices** (player can pick or say “surprise me”).  
4. Run **Scene Template** (prompts + tests).  
5. Write **Outputs** (beats, relationship deltas, notes, any item/clock changes).

> Fallback: if the player doesn’t choose, roll 1 from top 3 weighted options.

---

## 3) Categories & Examples

### 3.1 Leisure & Social
- **Market Crawl (Refugee City):** food stalls, bootleg tapes, street games.  
  *Prompt:* *“What scent drags you down an alley?”*  
  *Test:* Social/Streetwise → *Success:* rare spice or rumor; *Complication:* pickpocket; chase or let go.
- **Bar / Music Night:** live cover of a Ghost anthem, cramped dance floor.  
  *Prompt:* *“What lyric unlocks a memory?”*  
  *Hook:* meet 1 new civilian or run into a rival.
- **Observation Deck:** stargaze, letters to the dead.  
  *Hook:* quiet +bond with an NPC; +1 Morale if scene lands.

### 3.2 Projects & Repairs
- **Wrench Time:** fix a rattling panel on your bird; customize a charm on the console.  
  *Test:* Tools/Tech → *Success:* minor ship perk tag; *Comp:* short; owe deck chief an apology hour.
- **Personal Mod:** sew a patch; tune a guitar; 3D‑print a trinket.  
  *Hook:* token becomes a later **Anchor** in a crisis.

### 3.3 Training & Wellness
- **Gym / Sparring:** sweat, banter, bruise. Rival shows up.  
  *Test:* Physique/Cool → *Success:* +1 next physical test; *Comp:* strain; bruise as scene color.
- **Flight Sim (Off‑Roster):** you and an NPC run a private scenario.  
  *Hook:* discover an unusual tactic; seed future gambit.
- **Medical Check / Counseling:** grief session; nicotine patch; med scans.  
  *Outcome:* clear conditions, unlock secret; or refuse → write stubbornness.

### 3.4 Faction / Politics / Faith
- **Council Watch:** sit in on an argument about rations, labor, or security.  
  *Hook:* pick a side (soft); NPC remembers.  
- **Chapel / Ritual:** memorial wall, candles, quiet vows.  
  *Hook:* +bond with those who share this ritual.

### 3.5 Dates & Intimacy
- **Coffee & Walk:** slow talk; hands nearly touch.  
  *Gates:* relationship ≥ 20 (unless `impulsive`/`casual_ok`).  
  *Outcome:* small kiss, in‑joke, or clearly platonic.  
- **Private Music Night:** cramped bunks, shared earbuds, breath close.  
  *Outcome:* set **Intimacy Flag**; open **Sexting** at lower threshold for certain traits.  
- **Messy Make‑up:** rivals-to-lovers spark; argument flips to heat.  
  *Gate:* `drama_affinity` or strong rivalry.  
  *Outcome:* **Bond + chaos**; jealousy hooks elsewhere.

### 3.6 Errands & Civics
- **Volunteer Shift:** clinic triage / recycler maintenance / child care.  
  *Outcome:* goodwill ledger; witness a small scandal.  
- **Teach a Class:** basic tools, safe flight, self‑defense.  
  *Hook:* spot a talent → **Refugee Promotion** candidate.

### 3.7 Leave Destinations (Shore Leave)
- **Cruiseliner Hot Springs:** steam, soft neon, too‑loud laughter.  
- **Friendly Alien Visit (if any):** awkward hospitality, exotic customs.  
- **Hab Barge Gardens:** oxygen‑rich stroll under grow‑lamps.  
- **Derelict Museum (secured):** haunting exhibits of pre‑Fall Earth.

---

## 4) Relationship & Messaging Hooks
- Apply **relationship deltas** based on category outcomes (±1–5 typical).  
- **Traits:** `impulsive`, `drama_affinity`, `jealousy`, `poly_ok`, `casual_ok` alter gates and pacing.  
- **Messaging:** after scenes, auto‑queue DMs (thank‑yous, photos, late‑night doubts).  
- **Chaos Windows:** on heated arguments, a subset of NPCs may flip to intimacy if tags allow.

---

## 5) Outputs (Deltas)
Write into `_campaigns/<pc>/data/session_XXXX/`:
- `beats.json` → scene summary, quotes, outcomes.
- `relationships.json` → per‑NPC delta entries.
- `notes.md` → souvenirs, observations, rumors.
- `equipment_deltas.json` → crafted trinkets, lost items.
- `character_sheet_delta.json` → stress/fatigue relief or minor strains.

---

## 6) Tables (JSON-backed)
Backed by: `development/data/downtime_activities.json`, `downtime_scenes.json`, `date_hooks.json`, `leave_destinations.json`, `city_locations.json`.

**Example roll prompt:** *“Pick two from the shortlist or say ‘surprise me’.”*

---

## 7) Example Downtime (Worked)
- **Pick:** Market Crawl → Bar/Music.  
- **Market:** buy bootleg Ghost tape; pickpocket attempt → you chase, lose them, meet a refugee kid who returns your patch. **Bond +2** (kid), write **rumor**.  
- **Bar:** cover of *Rats* hits; your wingmate confesses they’re scared to fly nights. You promise to swap. **Bond +3**, **Fatigue –1**, queue DM.

---

## 8) Integration
- **Military Life:** Standby aftermath can spill into Leisure or Gym scenes.
- **Refugee Pool:** Volunteer/Teach scenes can mark candidates for PROMOTE.
- **Plot Engine:** Downtime rumors can foreshadow episodes; dates can collide with crises.
- **Messaging Engine:** opens new threads; sext gates vary by trait & recent beats.
