# Cinematic Intro Pipeline — Final Draft (v1)

> **Scope:** Always-on opener for any new campaign start.  
> **Tone:** Slice-of-life → sudden astrophobia → R‑rated survival → Kuiper Belt rendezvous → *Thronebreaker* fold.  
> **Source Engines:** `game_files/system/engines/dice.json`, `.../engines/conflict_*.json`, `.../engines/encounters.json`, `game_files/encounters/*`  
> **Outputs:** Relationship beats, refugee joins, injuries, gear flags, starting faction clocks, and the Fleet muster state.

---

## 0) Design Goals (Invariant)
- **Always starts normal.** A mundane vignette invests the player emotionally before the knife twists.
- **Shock of scale.** Astrophobia: titanic silhouettes bloom in the sky; physics groans; comms melt into screams.
- **Agency under fire.** A short chain of **decisions** with meaningful pass/complication branches.
- **New faces.** **2–4 refugee strangers** join as survival companions (selected from the Refugee Pool; see that engine).
- **Canon funnel.** All paths collapse to the **Kuiper rendezvous** and the *Thronebreaker*’s **Eldritch Fold**.
- **Persisted state.** Deltas are written into `_campaigns/<pc>/data/session_XXXX/` only (never mutate `game_files/` in Play).

---

## 1) Beat Map (Flow)
1. **Vignette: Ordinary Life (2–4 minutes RP)**
   - Locale seeds (roll or pick): **Orbital Mall (Luna)** · **Cruiseliner “Saffron Tide”** · **Concert Dome** · **Station Food Court** · **Transit Hub** · **Night Market**.
   - Micro-prompts: small talk, petty stakes, personal quirks; log 1× **Personality Tell** for PC.

2. **Astrophobia Event (0 → 30s)**
   - Visual: shadows crawl across ceilings; windows turn to oceans of metal. DRADIS/ATC overrun. *“Unknown gravitic wells forming…”*
   - Cue: sirens, PA failures, fragmentary news. Run **Morale Check** (dice engine) → sets initial **Composure** state.

3. **Impact & Panic (2–3 decisions)**
   - Branching survival challenges (see §3 Tables). Use **Conflict: Civilian Chaos** and **Environmental Hazards** modules.
   - First **Refugee Companion** intersects (stranger; assist or hinder). Log relationship beat (±).

4. **Flight Corridor (the Gauntlet)**
   - Escalating set-piece: collapsing tramlines, hull breaches, looters, fire doors, micro‑debris.
   - **2nd–4th Refugees** can hook here; keep total to **2–4**.

5. **Extraction & Egress**
   - Exit vectors: shuttle berth, service tug, escape pods, hitching on a lifter, or boarding *Saffron Tide* (luxury liner).
   - On Failures → injuries, lost gear, or a **costly rescue** by an NPC (log debt).

6. **Kuiper Belt Rendezvous**
   - Panorama of last ships. *Thronebreaker* coordinating frantic musters; fighters dying on the rim.
   - **Fleet Template:** 1× Battleship (flag: *Thronebreaker*), **9×** assorted military ships, **30+** civilian craft (named as needed).

7. **The Eldritch Fold**
   - Ritualized spin-up; reality drifts; prayer on the decks. The fleet tears space and vanishes.
   - **Session handoff:** Play formally begins post‑Fold with PC as **Refugee** awaiting processing.

---

## 2) GM Running Order (Quick Card)
1. Pick **Locale** and **Mood** → roleplay 2–4 minutes.
2. Trigger **Astrophobia** cue → call for **Composure** (dice).
3. Run **3 Challenges** total (mix hazards & social). On 2nd challenge, insert **Refugee #1**; on 3rd, insert up to **#2–#4**.
4. Resolve **Extraction** (vehicle/pilot/engineering/social). Award **Consequences**.
5. Narrate **Kuiper Muster** → set Fleet clocks.
6. Perform **Fold** → write session deltas; queue **Intake & Assignment** scene.

---

## 3) Tables & Prompts

### 3.1 Vignette Seeds (d6)
| d6 | Locale | Opening Prompt |
|---:|---|---|
| 1 | Orbital Mall (Luna) | Picking a jacket; clerk upsells “anti‑vac chic.” What do you splurge on? |
| 2 | Cruiseliner “Saffron Tide” | Neon pool party, bass line like heartbeat. Who did you just impress? |
| 3 | Concert Dome | Strobe, synth‑choir—your song hits. What lyric dismantles your guard? |
| 4 | Station Food Court | Last bite of noodles; a stranger asks to share your table. |
| 5 | Transit Hub | Delayed shuttle; you notice a nervous couple arguing. Intervene? |
| 6 | Night Market | Lanterns, spice smoke; a fortune vendor offers a free reading. Take it? |

### 3.2 Astrophobia Cues (d8)
1. Window becomes eclipsed by a hull like a continent. 2. Gravitic moans; cutlery crawls. 3. PA repeats *“Remain Calm”* until it slurs. 4. Live news shows a city wink out. 5. Kids point—*“stars are bending.”* 6. Fighters streak past, tracer spiders. 7. Emergency lighting paints everyone arterial red. 8. The air tastes metallic.

### 3.3 Survival Challenges (roll 2–3)
| Type | Example Prompt | Test | On Success | On Complication/Fail |
|---|---|---|---|---|
| Hazard | Fire door stuck; smoke rising. | Physique/Tools | Door opens; +1 follower morale. | Choked; -1 Composure, minor burn. |
| Social | Panicked crowd blocks corridor. | Presence/Authority | Corridor clears; you earn gratitude. | You get separated; lose gear item. |
| Tech | Tram offline; manual override? | Tech/Interface | Tram limps; time saved. | Sparks—short; take 1 Stress. |
| Combat (last resort) | Looters threaten civvies. | Melee/Ranged | Drive off with warning shots. | Escalates to close-quarters scuffle. |
| Med | Wounded teen; quick tourniquet. | Medicine/Cool | Stabilized; future ally. | Bleeds out unless you accept delay cost. |

### 3.4 Extraction Vectors (choose/roll)
- **Shuttle Berth:** hot-launch; pilot checks; debris field.
- **Service Tug:** slow but armored; engineering checks.
- **Escape Pods:** claustrophobic; air leak clock; require rescue beacon.
- **Hitch a Lifter:** social + stealth; bribe/convince crew.
- **Cruiseliner Ride:** brief day of hedonistic denial before panic; later mass evac.

### 3.5 Kuiper Fleet Template
- **Military:** *Thronebreaker* (Flag), 1× Carrier or Arsenal Ship, 2× Cruisers, 6× Escorts.  
- **Civilian:** 30–80 ships (freighters, liners, hab barges). Name on demand.  
- **Status Clocks:** Fuel, Food/Water, Morale, Fighter Strength, Hull Integrity.

---

## 4) Outputs (Write Deltas Only)
Create/append in `_campaigns/<pc>/data/session_XXXX/`:
- `beats.json` → ordered scene beats with outcomes & quotes.
- `relationships.json` → entries for each Refugee companion (initial ±).
- `equipment_deltas.json` → items lost/found.
- `character_sheet_delta.json` → injuries, stress.
- `notes.md` → freeform flavor; first impressions; locale memory.

---

## 5) GM Prompts (Human or AI)
- *“Paint the normal: three sensory details, one petty desire.”*
- *“When the sky breaks, what do you protect first?”*
- *“Offer a stranger your hand or your orders—choose.”*
- *“Extraction demands a cost. What do you pay?”*
- *“At Kuiper, name one ship you’ll remember.”*

---

## 6) Integration
- **Refugee Pool Engine:** supply 2–4 strangers; return their join reasons & first beats.
- **Conflict/Dice Engines:** resolve checks; push Complications as scars, debts, enemies.
- **Messaging:** queue first “are you ok?” threads post‑Fold.
- **Plot Engine:** seed **Fleet Clocks** and 1× opening side‑plot (resource, unrest, or mystery).
