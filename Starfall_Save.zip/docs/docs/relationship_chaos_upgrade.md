# Relationship Chaos Upgrade (Skeleton)

Adds impulsiveness, drama-affinity, and style tags that alter pacing and responses.

## New Traits
- `impulsive`, `drama_affinity`, `casual_ok`, `jealousy`, `poly_ok`

## Messaging Rules
- Early flirt/sext gates for certain profiles
