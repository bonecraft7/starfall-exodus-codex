# Solar Collapse Chronicle (Skeleton)

72-hour massacre timeline with vignettes by location.

## Template
- Hour 0: First strikes
- Hours 1–12: Orbital losses
- Hours 12–48: Evacuations & failures
- Hours 48–72: Last stands
