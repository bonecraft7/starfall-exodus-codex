# Culture: Ghost & Mama Emeritus (Skeleton)

Music-as-myth; songs as morale & ritual. Venues aboard the refugee city.

## Hooks
- Holo-concert nights, anthem scenes, NPC band subs
