# Refugee Pool Engine — Final Draft (v1)

> **Purpose:** Manage the crowd of surviving civilians; elevate suitable candidates into active roles on‑demand; introduce vivid new faces during play.  
> **Data Sources:** `game_files/catalogs/npcs/refugees/**.json` (+ images), optional tags in `identity_fields/*`.  
> **Play Contract:** In **Play**, never mutate `game_files/`. All promotions and edits are **deltas** under `_campaigns/<pc>/data/session_XXXX/`.

---

## 0) Concepts
- **Refugee:** Civilian survivor with a portrait, appearance, and personality hooks. Initially unaffiliated.
- **Promotion:** Story event that moves a Refugee into a **Role Pool** (Pilot Trainee, Marine, Engineer, Medic, Civic Vendor, Intel Aide, etc.).
- **Summon:** Temporarily spotlight a Refugee for a scene (merchant, witness, neighbor) without promotion.
- **Heuristics:** Selection favors **story need → skill fit → relational gravity → randomness**.

---

## 1) Data Model (JSON Delta Schema)
Create or append `session_XXXX/refugee_promotions.json` entries like:
```json
{
  "refugee_id": "ref_za-1293",
  "name": "Ines Bernard",
  "source_path": "game_files/catalogs/npcs/refugees/ines_bernard.json",
  "timestamp_utc": "NOW_UTC",
  "action": "promote",
  "role": "pilot_trainee",
  "unit_hint": "Scythe Wing",
  "reason": "Manual flight hours + CAP shortage",
  "relationship_seed": 6,
  "notes": "Met during Luna tram collapse; quick-thinking under fire."
}
```
**Other actions:** `"summon"`, `"demote"`, `"retire"` (rare).

### Role Pools (canonical keys)
- `pilot_trainee`, `marine`, `engineer`, `medic`, `deck_crew`, `intel_aide`, `civic_vendor`, `transport_pilot`, `science_aide`

---

## 2) Selection Heuristics (Deterministic + Spice)
1. **Story Need:** What does the current plot/mission require? (e.g., explosives expertise, shuttle pilot, translator)  
2. **Skills/Tags Match:** Parse refugee profile for keywords in **bio**, **profession**, **hobbies**, **traits**.  
3. **Relational Gravity:** Prefer refugees with recent **beats** with the PC or squad.  
4. **Diversity & Surprise:** Avoid repeats; occasional wildcard pick for drama.  
5. **Availability Gates:** Already promoted? Injured? Conflicting duty? Skip.

> **Tie‑breaker:** favor **contrasts** (soft-spoken medic in a hard squad; comedian in grim arc).

---

## 3) API (GM Macros / Pseudocode)
```text
SUMMON(refugee_query, purpose) -> {refugee}
PROMOTE(refugee_id, role, unit_hint?, reason?) -> delta_written
LIST_POOL(role?) -> [{refugee, status}]
RELATE(refugee_id, delta, beat_note) -> relationships.json updated
```
**Queries:** name contains, tag contains, country, portrait hash, last‑seen‑with(PC/NPC).

---

## 4) Scene Hooks (Use Immediately)
- **Intake Line:** Bureaucracy, biometrics, ration card; the PC cuts red tape for someone.
- **Bunk Lottery:** Room assignment drama; the PC mediates, earns a favor/enmity.
- **Food Stall:** Improvised market; refugee runs a noodles cart—recurring contact.
- **Clinic Overflow:** Med-bay asks for volunteers; triage together → bond.
- **Deck Crew Tryouts:** Maintenance sergeant spot-tests a small crowd (tools, grit).
- **Simulator Glimpse:** Open seats; a refugee surprises everyone with reflexes.

---

## 5) Promotion Events (Examples)
| Role | Trigger | Test | Outcome (Success) | Outcome (Complication/Fail) |
|---|---|---|---|---|
| Pilot Trainee | CAP shortage + sim access | Reflex/Interface | Accepted to pipeline; call‑sign seed. | Washed at step 1; given deck‑crew slot. |
| Marine | Boarding threat | Physique/Courage | Assigned to squad; basic kit issued. | Injured in training; med leave + bond. |
| Engineer | Reactor hiccup | Tech/Tools | Added to shift; “little fixes” arc. | Shorts power; owes apology/work hours. |
| Medic | Outbreak scare | Medicine/Cool | Clinic badge; on-call pager. | Freezes once; mentor assigned. |

> Write each as a **beat** in `beats.json`, and a delta entry in `refugee_promotions.json`.

---

## 6) Outputs (All Deltas)
- `refugee_promotions.json` (see schema)
- `relationships.json` (± seed on join)
- `beats.json` (promotion scene)
- `notes.md` (quirks, speech tics, promises)

---

## 7) GM Prompts
- *“From the line of tired faces, one pair of eyes finds you. Why them?”*
- *“A test that looks easy, but reveals character—what is it?”*
- *“If they join, who quietly resents it?”*
- *“Name the tool they never let go of.”*

---

## 8) Integration
- **Cinematic Intro Pipeline:** supplies the first 2–4 strangers with a shared survival tale.
- **Plot Engine:** can request `PROMOTE` when a role gap opens mid‑arc.
- **Relationship Engine:** logs beats; traits like `impulsive`/`drama_affinity` can accelerate bonds.
- **Messaging:** opens DMs post‑promotion (welcome, jitters, late‑night doubts).
