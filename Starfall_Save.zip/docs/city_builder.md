# Refugee City Builder — New Arcadia (Final Draft v1)

> **Purpose:** Give the Thronebreaker’s civilian zone a living heartbeat: districts, shops, permits, security perimeters, events, and NPCs—ready for Downtime, Plot, and Military Life crossovers.  
> **Contract:** Civilian zones are **protected**; military perimeters remain firm. The city grows through **events** and **permits**, not silent retcons.

---

## 0) City at a Glance
**Name:** **New Arcadia** (working name; born of stubborn optimism).  
**Interim Mayor:** **Meera Kazemi**, former orbital civil engineer—steady hands, soot under the nails.  
**Districts:** Lantern Market • Echo Bar Row • Observation Row • Maker Bay • Chapel of Names • Admin Spine.  
**Population:** Thousands; stalls and bunks braided through cargo decks and converted hangars.  
**Security:** Concentric **Green / Amber / Red** perimeters with Marine checkpoints.

---

## 1) Governance
- **Interim Mayor** Meera Kazemi (civil) + **Deck Liaison** Chief Warr. **Luca Vance** (mil).  
- **Councils:** Market Wardens, Faith Circle, Youth Committee.  
- **Permits Office:** Processes vendor & venue licenses; enforces curfews and safety.

**GM Macros (conceptual):**
```
PERMIT_REQUEST(applicant, type, location) -> {status,cost,timer,conditions}
SCHEDULE_EVENT(event_id, date, location) -> calendar entry
SUMMON_LOCATION(tag or district) -> {venue, owner, vibe, hook}
SECURITY_STATE(code) -> apply restrictions (see §4)
```

---

## 2) Districts (Use & Color)
- **Lantern Market:** neo‑tokyo aisles, AR banners, spice smoke. Bargains, pickpockets, gossip.  
- **Echo Bar Row:** bars, dance floors, an adult revue club (*Velvet Drape*)—strict ID & consent rules.  
- **Observation Row:** viewports, memorial wall overflow, candles. Quiet drama.  
- **Maker Bay:** printers, scrap art, fix‑it crews; barter culture.  
- **Chapel of Names:** interfaith alcoves; the wall of the lost.  
- **Admin Spine:** permits, ration office, security desk, juvenile mediation.

---

## 3) Venues & Shops (Starter Set)
Each entry has: **id, name, district, type, owner, hours, tags, vibe, hooks**. See `data/city/locations/*.json`.

Highlights:
- **Hydra Noodles** (stall) — broth that tastes like the old sun; owner swears by a secret algae.  
- **Echo Bar** (music) — live Ghost covers on Thursdays; cramped, sweaty, loud.  
- **Velvet Drape** (adult performance) — consent-forward revue, no explicit acts on camera; rumor magnets.  
- **Print & Pray** (maker) — will fix your panel and engrave your vows.  
- **Lantern Exchange** (pawn) — lost & found for a price; plot device central.  
- **Quiet Orbit** (tea) — tea service, soft talk, grief seen kindly.  
- **Patchwork Clinic** (pop‑up) — volunteer med shift; triage hooks.

---

## 4) Security Perimeters
**Green (Civil Zone):** open 06:00–24:00; curfew at 24:00. Random bag checks.  
**Amber (Buffer):** Marine checkpoints; ID & permit scans; closes on **RED** or **SABLE** codes.  
**Red (Restricted):** Flight deck, reactor, magazines; civilians forbidden without escort.

**Code Integration:** WHITE/AMBER/RED/SABLE posture affects curfews and patrol density. See `security_zones.json`.

---

## 5) Permits & Licenses
- **Vendor A (stall)** — 30 days; safety inspect; tokens_2/week.  
- **Vendor B (fixed shop)** — 90 days; power allotment; tokens_5/week.  
- **Performance** — stage times; decibel cap; bouncer required after 22:00.  
- **Alcohol** — tied to venue; strict hours; sobriety spot‑checks.  
- **Adult Venue** — consent policy on file; bouncer & privacy rules; no recordings.  
- **Alien Visa (hospitality)** — sponsor required; zone restricted.  
- **Night Market Extension** — curfew waiver for festivals.

See `permits.json` for costs, timers, and conditions.

---

## 6) Event Engine (City)
Events are JSON templates in `data/city/events/*.json`. Types include:
- **Grand Opening** (venue) — ribbon, discounts, rival shade.  
- **Memorial Night** (chapel/observation) — solemn arcs, rumor resets.  
- **Market Festival** (lanterns, food) — +morale; pickpocket subplots.  
- **Cultural Exchange** (Kaari/Ferrox nights) — etiquette tests, trust shifts.  
- **Blackout Drill** (security) — practice under SABLE; mistakes become hooks.

Each event lists **setup → beats → climax → outcomes** and permit prerequisites.

---

## 7) NPCs (Starter)
- **Meera Kazemi** (Interim Mayor) — **calm, stubborn, engineer-brained**; takes notes on her wrist.  
- **Luca Vance** (Deck Liaison) — **dry humor, safety zealot**; quietly feeds tips to the PC.  
- **Rae “Hydra” Song** (Hydra Noodles) — **warm, nosy**; hears everything.  
- **Sable Inez** (Velvet Drape) — **performer‑owner**, **consent hawk**, scandal‑magnet by rumor only.  
- **Brother Jun** (Chapel) — **gentle, fierce boundaries**; officiates memorials.  
- **Kyou Tan** (Lantern Exchange) — **pawn‑broker**, **grin like a trap**.

Full sheets in `data/city/npcs/*.json`.

---

## 8) Integration
- **Downtime Engine:** immediate menu hooks (Market, Bar/Music, Volunteer, Date spots).  
- **Relationship Chaos:** jealousy rumors, messy triangles, aftercare scenes.  
- **Plot Engine:** festivals can mask thefts; openings attract raiders; visas trigger diplomacy arcs.  
- **Military Life:** Duty/Liaison scenes; curfew calls; crowd control after drills.

---

## 9) GM Prompts
- *“What smell says ‘home’ tonight in the Lantern Market?”*  
- *“Who recognizes you from before the Fall—and what do they want?”*  
- *“The permit clerk asks for a favor. What’s the cost?”*

