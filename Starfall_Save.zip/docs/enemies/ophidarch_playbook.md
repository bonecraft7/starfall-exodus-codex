# Ophidarch Seraphate — Enemy Playbook (Stub v1)
- **Show, don't explain**: geometry, bells, wrong comms. No lore dump.
- **Siege Engines**: Black Ladder, Ghost Net, Gravemill Towers, Drone Wall, Knife‑Night.
- **Moves**: Split the lane; Mirror the signal; Make the sky feel wrong; Cull the line.