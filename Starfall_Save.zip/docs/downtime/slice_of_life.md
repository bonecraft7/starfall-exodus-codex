# Slice‑of‑Life System (v1)

**Goal.** Give the pilot real breath between sorties—quiet markets, messy romance, hot springs on a liner, choir rooms—and let those choices ripple into the **clocks** (Fleet Morale, City Stability, Engineering Integrity) and **relationships (Chaos v2)**.

**Use at table**
1. **Call a Day Off / Leave** (trigger from mission end, festival permit, or morale ≥ 4).
2. **Pick an Activity** with `tools/downtime/pick_downtime.py` (or select from `data/downtime/activities.json`). 
3. **Frame the scene** using the activity’s *vibe* and *beats*. If on **leave**, choose a site from `data/downtime/leave_sites.json`.
4. **Invite 0–2 NPCs** (pull from Relationships). On entry, roll **Heart** to set the tone, or **Weird** if the place hums.
5. **Resolve**: pay the **costs**, claim **benefits**, tick a clock if listed, and adjust relationships via Chaos v2.
6. **Texting**: run `tools/downtime/schedule_texts.py` to throw in 1–3 messages (flirty, casual, thorny), tuned by *heat* and *chaos*.

**Tone**: gothic‑romantic. R‑rated in **scale**, not gore. Intimacy uses consent gates in Chaos v2.
