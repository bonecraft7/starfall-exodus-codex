# Agnes Persson Torres — Style Capsule: Boardwalk “Lazy Hot Girl”

VML‑derived from Paula’s skate/beach/EDM board. Capsule for her off‑duty/trendy looks that lean effortless and a bit goth.

**Core cues**
- Oversized tees off one shoulder with **bralettes meant to show** (triangle, lace, or cage).  
- **Low‑rise destroyed denim** with branded waistband peeks; plaid mini + fishnets; micro shorts and stud belts.  
- **Triangle thong bikinis** as tops at the beach or festivals.  
- Skate caps, spike chokers, chain belts; platform boots or chunky skate sneakers.

**Where to use**
- Boardwalks, skate parks, markets, hangar downtime, EDM festivals.

Files:  
- Wardrobe → `game_files/data/wardrobes/paula_torres_lhg.json`  
- Persona capsule → `boardwalk_lhg` in `game_files/data/refugees/personas/Paula_Torres.json`