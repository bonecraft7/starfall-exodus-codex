# Julia Axelsson — Opener Persona (Sweden • Eldritch Candidate)

**Look (VML‑derived):** sun‑blonde braids under a lived‑in cap; sea‑blue eyes; tan skin and freckles; tiny nose stud and hoops; dainty gold chains with a cross; long almond nails. Athletic swim‑core build.

**Style:** off‑shoulder tees, quarter‑zips, sports bras and cargos; triangle bikinis (often **thong**) with retro sunnies and caps; bralettes off duty.  
**Vibe:** sunny mischief, camera‑savvy, unflappable in crowds; caretaking streak.

**Skills:** boat handling, strong swimmer (lifeguard basics), crowd navigation/calming, short‑form video, mixology.  
**Eligible branches:** weird_support, morale_culture, intel_support.

**Eldritch Affinity — *Attention Resonance***  
When many eyes are on her, Julia reports a controlled *pressure* and skin prickle; ritual teams note increased stability when she serves as a **gaze anchor**. Training track: `gaze_anchor_apprentice`. Risks: fatigue/after‑crash if overused.

**First‑meet hooks:** 'we're alive' selfie mid‑sprint • gives you her lucky cap before vaulting a barrier • bikini strap tourniquet with a grin.

**Consent & kinks:** enthusiastic consent; enjoys being watched yet demands respect. Tags mirror JSON (no graphic content).