# Julia Axelsson — Style Capsule: Party‑Pier “Lazy Hot Girl”

VML‑derived capsule for Julia’s trendy free‑spirit look. Oversized tees/tanks with visible bralettes, low‑rise shredded denim, micro eyelet minis, triangle bikinis as tops, caps + hoops + belly chains. Perfect for beach clubs, markets, hangar downtime, or crowd‑moving where she still wants a camera‑ready vibe.

**Core cues**
- Off‑shoulder crop tees; deep armhole tanks (*bralette meant to be seen*).
- Light‑wash low‑rise ripped jeans with branded waistband peeks.
- White eyelet micro‑mini with tan belt; grey slouch sweats + cropped hoodie.
- Triangle bikini tops (black/polka dot); thong sets for swim.
- Black NY cap, big hoops, layered gold, belly chains; white sneakers or slides.

**Files**
- Wardrobe: `game_files/data/wardrobes/julia_axelsson_lhg.json`
- Persona capsule: `party_pier_lhg` inside `game_files/data/refugees/personas/Julia_Axelsson.json`