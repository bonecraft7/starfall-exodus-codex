# Chihiro Watanabe — Style Pack (VML derived)

**Palette:** black, charcoal, teal, acid green, bone white, silver hardware  
**Motifs:** skulls, pentagrams, chains, Burberry-style tan check (ironic accent)

**Core pieces**
- Tops: off‑shoulder knit crop; strappy skull corset tank; asym poncho crop; black cut‑out bodysuit
- Bottoms: plaid pleated **tan check** mini; distressed studded shorts; micro denim chain‑ring skirt; ripped black jeans over **white fishnets**
- Legwear: fishnets (black/white); thigh‑highs + garters
- Footwear: platform boots; white sneakers
- Accessories: spike choker, O‑ring chains, star/pentagram harness, oversized cross, grommet belt
- Swimwear: **thong bikinis** (triangle tops) in black/teal/acid green — mirrored shades
- Lingerie: **bralettes**, cut‑out bodysuits, skull‑print sets

**Affinities**
- Burberry-style tan check accents (0.7) on skirt/scarf/ribbons
- Fishnet textures (0.8), chains (0.6)

Use with `game_files/data/wardrobes/chihiro_watanabe.json` for outfit generation per scene.