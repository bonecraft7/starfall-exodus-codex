# Julia Axelsson — Starter Survivor
**Culture:** Sweden · **Age:** 21  
**Vibe:** free-spirited, trend-savvy, teasing, surprisingly brave

## Appearance
Lazy-hot Y2K muse: sunlit blonde, cap pulled low, bralette under oversized tees, micro skirts or shredded denim riding low over thong straps.
- Freckles and a permanent beach glow; hoop earrings and layered necklaces
- Polished nails, lip-glossed smirk; sleeps in bikinis, wakes camera-ready
- Trendy mixing of Burberry check, fishnets, and sporty caps

## Personality
Unbothered flirt who wanders toward the interesting; heart-on-sleeve once you're in her circle.
- Ticks: doodles hearts on mission slates, poses for selfies mid-chaos then gets serious
- Fears: being boring, long silences with no music

## Service Eligibility
Tracks: Eldritch, Ops/Heart  
Notes: Open imaginative suggestibility; talent for pattern-spotting in noise.

## Romance Profile (Adults Only)
Bra: bralette · Panty: thong  
Major: Voyeurism: being watched by anyone
