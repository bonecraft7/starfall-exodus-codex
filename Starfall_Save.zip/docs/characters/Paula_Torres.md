# Paula Torres — Opener Persona (guided)

**Origin:** Mexico (coastal). Spanglish; beach-town heart.  
**Day vibe:** skateboard + cap + mirrored shades; cropped tee, cut‑offs.  
**Night vibe:** alt/EDM goth — skeleton dress, cut‑out bodysuit, plaid mini + fishnets, platform boots.

**Personality:** laid‑back and sunny, but observant; drops quick, poetic one‑liners. EDM fan; dances first, asks later.

**First‑meet hooks:** share an earbud during the run • board-as-shield detour • pushes water into your hand and counts your pulse.

**Branches:** morale/culture, medic, deck, intel support, drone‑cam ops.  
**Chaos/Heat:** 2 / 3 (flirty, not reckless).  
**Consent:** enthusiastic yes, public affection okay if safe; hard boundaries respected.

> Underlayers preference: bralettes & thongs (style note only).