# Paula Torres — Starter Survivor
**Culture:** Mexico · **Age:** 22  
**Vibe:** laid-back, warm, EDM day-raver, quietly insightful, flirty mischief

## Appearance
Sun-bronzed boardwalk siren; long beach-brown hair under a snapback, mirrored shades, cut-off tees and board shorts over neon bikinis.
- Athletic, toned waist; board-rash scars tell surf stories
- Freckles and gold jewelry; playful sunglasses rotation
- Wardrobe leans skate/surf + goth tees; thong lines obvious by choice

## Personality
Chill poet of sun and asphalt; reads people well, jokes first—truth later.
- Ticks: taps rings to the kick drum in her head, collects beach sand vials from worlds visited
- Fears: open water at night, being penned in without exits

## Service Eligibility
Tracks: Starfighter, Ops/Heart  
Notes: Excellent motion sense and horizon-reading from surfing; quick reflexes; comfort with helmets/masks.

## Romance Profile (Adults Only)
Bra: bralette · Panty: thong  
Major: Romantic exhibitionism with playful bravado
