# Chihiro Watanabe — Starter Survivor
**Culture:** Japan · **Age:** 24  
**Vibe:** magnetic, mischievous, showwoman, curious about forbidden tech, protective of fans

## Appearance
Neon-occult idol: sea-green dreadlocks threaded with charms, silver piercings, blackliner eyes; goth streetwear over skin-sharp silhouettes.
- Dermal piercings, septum ring; glyph tattoos with stage mythology
- Mixed media hair beads that clack softly when she turns
- Fishnets, chain-belts, crop tanks—stage-ready even in chaos

## Personality
A performer who believes symbols hold power; playful but calculating with image and myth.
- Ticks: tunes ambient noise like a mixing board, whispers backstage pep talks before danger
- Fears: becoming a commodity again, losing creative control

## Service Eligibility
Tracks: Eldritch, Ops/Heart  
Notes: High psi-resonance indicators; thrives under ritual structure when self-directed.

## Romance Profile (Adults Only)
Bra: bralette · Panty: thong  
Major: Shower sex
