# Chihiro Watanabe — Opener Persona (celebrity, eldritch-tuned)

**Origin:** Japan (Kantō). Underground celebrity in alt‑JP culture — stage name **Neon Onryō**.  
**Look:** vivid teal dreads threaded with beads; geometric/floral ink; septum + cheek dermals; black winged liner and ritual streaks on stage.  
**Style:** street‑goth (oversized tees, shorts, chains, fishnets) ⇄ high‑drama (spiked cap, hooded slit dresses, platform boots).  
**Underlayers:** bralettes + thongs (style reference).

**Vibe:** deadpan tease in public, soft in quiet rooms; controlled chaos on stage, meticulous off.  
**Skills:** audio/FX rig modding, crowd reading, basic code for AR shows, rhythm/balance; **fold‑noise synesthesia** — hears signal in static.  
**Eligible branches:** weird_support, intel_support, engineering, morale_culture.  
**Eldritch track:** *choir‑handler apprentice* — can mirror Hymn motifs.

**First‑meet hooks:** denies being famous while saving your life • chain‑belt tourniquet + “hum with me” • locks you under her arm and ghosts a route.

**Consent & kinks:** strict consent/safewords. Major: **shower**. Minors kept as tags (see JSON).