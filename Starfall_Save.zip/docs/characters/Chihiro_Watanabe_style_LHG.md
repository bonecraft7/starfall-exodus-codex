# Chihiro Watanabe — Style Capsule: Incognito Y2K “Lazy Hot Girl”

Derived from the latest VML board. This is her **incognito** / off‑duty capsule when she leans trendy and effortless, okay with visible bralettes and thong‑tied swim tops as streetwear.

**Core cues**
- Oversized sports/college crop tees slipping off one shoulder; **bralette is meant to be seen**.
- Low‑rise, shredded **light denim** with branded waistband peeks.
- Micro **eyelet** minis with a tan belt; slouchy grey sweats + cropped hoodies.
- **Triangle bikinis** (often **thong** sets) double as tops.  
- Black NY cap, large hoops, layered gold crosses, **belly chains**, retro sunnies.

**Use in scenes**
- Market runs, pier walks, hangar downtime, crowd escapes while dodging recognition.
- Pairs well with the **Celebrity Recognition** hook — apply `sunglasses`/`cap` cover mods when this capsule is active.

Files:
- Wardrobe: `game_files/data/wardrobes/chihiro_watanabe_lhg.json`
- Persona style updated: `game_files/data/refugees/personas/Chihiro_Watanabe.json`