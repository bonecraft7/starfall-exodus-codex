# Élise Martin — Starter Survivor
**Culture:** France · **Age:** 23  
**Vibe:** melancholy-romantic, composed, secretly ditzy at times, fiercely loyal

## Appearance
Morticia-in-vacuum: black lace bell sleeves, corset waist, cathedral eyeliner; platinum-black hair and chainwork catching light.
- Quietly regal posture; voice a low velvet hum
- Fishnets and platform boots; sheer overlays revealing lace underlayers
- Glossed dark lips; silver crosses/bats among chains

## Personality
Writes poems about doomed worlds; laughs at herself when she trips over the cape.
- Ticks: recites verse to steady nerves, names starfighter parts in French
- Fears: dying without finishing a stanza, bright medical lights

## Service Eligibility
Tracks: Starfighter, Ops/Heart  
Notes: Strong night-vision and calm under pressure; tactile finesse with flight controls.

## Romance Profile (Adults Only)
Bra: demi-bra · Panty: g-string  
Major: Sexting
