# Élise Martin — Style Capsule “Nocturne”
**Use:** Slice-of-Life, Wardrobe pulls, Uniform allowances, Episode color

## Read
Morticia-in-vacuum. Lace bell sleeves, corseted waist, chains waterfalling to an O-ring choker; fishnets and tall combat boots. Two‑tone hair (platinum/black), cathedral eyeliner, glossed dark lips.

## Wear List (pull 1–2 tops, 1 bottom or dress, 1 footwear, 2 accessories)
- **Tops:** lace bell-sleeve blouse · distressed oversized knit (cross motif) · fitted high-neck top · studded tee · sheer lace gown
- **Bottoms:** slit maxi with lace inset · micro pleated skirt · leather mini · lace leggings
- **Intimates (visible-ok):** demi-bra (black lace), plunge cage bra; g-string/thong
- **Swim:** black string bikini thong + crochet/mesh duster, wide-brim hat
- **Footwear:** platform combat boots · knee-high lace-ups · black wedges
- **Accessories:** O-ring choker · multi-chains · lace/fishnet gloves · garter belts · silver crosses/bats/stars · coffin nails

## Uniform Notes
- Chain-safe only; no dangling metal in cockpit.
- Aramid lace trim allowed on undershirt edges.
- Personal choker off-duty; flat tag on-duty.
- Heavy gloss off before mask fitting.

## Dice/Engine Hooks
- **Flair Entrance:** If outfit includes bell sleeves or sheer lace, gain +1 Flair on the first social beat in scene.
- **Noticed Detail:** First time a buckle/garter audibly clicks in a scene, trigger a Relationship micro-beat.
- **Nocturne Edge:** In low-light scenes, +1 Edge to Maneuver *or* ECM (once per scene).

## Episode Seeds
- Poetry Night in the Refugee Quarter (lace gown).
- Glow-Deck CAP Briefing (studded tee + micro pleats).
- Shore Leave on Cruiser Lido (black bikini + crochet duster).
