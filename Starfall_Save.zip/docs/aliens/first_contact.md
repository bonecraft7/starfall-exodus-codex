# Alien Protocols — First/Second Contact (v1)

> **Truth of the moment:** We are burned and wary. Curiosity survives anyway. **Second contact** should feel **intense**—city on edge, CAP above, MPs gentle but present. Friendly or not, it’s always a plot engine.

**Where used:** Plot engine arcs, Fleet posture, City scenes, Diplomacy clocks, Join‑Fleet pipeline.

---

## Posture on Approach
- **Default:** **AMBER** fleet posture; Air Wing CAP ×1, Ready ×1; city soft curfew near docks.
- If unknown ships match Ophidarch silhouettes → immediate **RED** and disengage pattern.
- **SABLE** only during ritual exchanges or if Weird sensors advise quiet.

---

## Contact Ladder (GM runs top‑down; skip if prior trust exists)
1. **Detection & Identification** — DRADIS marks, hull silhouette, emissions. No hails yet. Log to `diplomacy_clocks` as *attention*.
2. **Hails in Clear** — plain greeting + intent; no coordinates yet. Offer rendezvous geometry with offsets.
3. **Beacon & Mirror** — exchange physical or line‑of‑sight codes (lamps/lasers). No network joining.
4. **Escort & Perimeter** — assign corridor; CAP flies high and visible; weapons *cold* but ready.
5. **Parley Site** — choose neutral hull or airlock with **double‑glass** (two doors, two truths). Medics on standby.
6. **Gift & Story** — both sides give a small thing and one truth about their scars.
7. **Limited Trade Test** — barter small supplies or data. Watch for bad faith.
8. **Pilot Visit / Cultural Exchange** — one crew on each side; no command crew first visit.
9. **Draft Terms** — if things hold, pass to **Join‑Fleet** pipeline.

**Fail‑Safes:** At any stage, a single wrong note → **AMBER → RED** pivot, corridor clearance, polite break.

---

## Comms & Etiquette
- Short, slow, sincere. Don’t fill the sky with words.
- No boarding without explicit invitation and mirrored terms.
- No scanning of bodies or cores without consent.
- Treat their symbols as **names**, not **trophies**.

---

## Safety & Tone
- No slurs, no dehumanization. Fear is voiced by **scale and uncertainty**, not cruelty.
- Intimacy stays PG‑13 and is always consensual; fade to black.
- The player can always say **HARD NO** to any cultural beat.
