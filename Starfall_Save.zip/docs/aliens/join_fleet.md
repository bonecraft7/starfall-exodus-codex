# Join‑Fleet — Terms, Statuses, and Process (v1)

> **Aim:** Let non‑Terran partners travel with the Armada without surrendering their identity—or endangering our people. Make it dramatic. Make it bureaucratic enough to feel real.

## Status Ladder
1. **Visitor** — dock rights with escort; no network; short stay.
2. **Convoy Guest** — may shelter in the ring; follows our lanes; no weapons hot without CAG consent.
3. **Auxiliary** — flies screen or logistics under local command; limited net keys.
4. **Ally** — mutual defense clause; intel cell exchange; routine screen duties.
5. **Protectorate** — we sponsor their safety; they accept our security perimeter.
6. **Member** — council voice; full convoy rights; shared doctrine drills.

## Non‑Negotiables (every level)
- No slavery or predation. No forced conscription.
- No biological or digital tampering without consent and oversight.
- No weapons hot in the civil ring except by emergency code agreed in advance.
- No scans of the Cathedral Drive internals, ever.

## Onboarding Steps
1. Intent note → 2. Safety review → 3. Corridor/dock plan → 4. Trade/mutual aid → 5. Intel & secrets → 6. Command liaison → 7. Trial period (1–3 episodes).

Paperwork lives in `development/data/aliens/join_fleet_terms.json` and `.../protocols.json`.
