# Fleet Manifest — Thronebreaker Armada (v1)

> **Contract:** Kuiper rendezvous shows a **flag carrier (Thronebreaker)**, **≥1 battleship**, **~9 other military hulls**, and **30+ civilian ships** as background lanterns. This file is the authoritative roster the AI references during play.

**Where used:** Cinematic Intro, Plot Engine (pursuit/escort), Squadron Ops (CAP/scramble), City (visas & trade lanes), Alien Join‑Fleet rules.

---

## Counts
- Military: 1 **flag carrier** (Thronebreaker) + **1 battleship** + **9 others** (cruisers/destroyers/escort/ECM).  
- Civilian: **30+** mixed hulls (liners, freighters, barges, tankers, ag, colony).

**Source of truth:** `development/data/fleet/fleet_manifest.json`

---

## Notes
- If a hull is **lost** or **peels off**, update `status` and log a beat.  
- Civilian names can be reused as “background” unless promoted into a plot.  
- Lanes & posture affect where ships fly (WHITE/AMBER/RED/SABLE).