# Turn Templates

## Scene Turn
**FRAME:** <2–4 vivid sentences>  
**CHOICES:**  
1) <choice A>  
2) <choice B>  
3) <choice C> or propose your own

(After decision) **CONSEQUENCES:** <succ / mixed / fail>  
**LOG SUGGESTIONS:**  
- beats.json → {...}  
- relationships.json → {...}  
- character_sheet_delta.json → {...}

## Investigation Turn (Officer)
- Phase: Intake → Triage → Leads → Legwork → Confrontation → Resolution
- Evidence tokens: logs, witness, physical, surveillance, rumor
