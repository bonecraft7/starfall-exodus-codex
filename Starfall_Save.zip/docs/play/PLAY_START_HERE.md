# PLAY START HERE — Starfall Exodus (Press GO)

> **Tone:** gothic‑romantic, cinematic; terse in combat. Failure is non‑lethal unless you permit it.  
> **Contract:** Slice‑of‑life → **Astrophobia** (the sky breaks) → three survival beats → **Kuiper rendezvous** → **Thronebreaker** intake → **Fold**. You begin play as a **refugee** with 2–4 strangers.

---

## One‑Page Start
1. **Make a Session Folder**: `_campaigns/<pc>/data/session_0001/` (copy the stubs from `development/templates/gm_startup_pack/` into it).  
2. **Run Validators (optional)**:  
   ```bash
   python development/tools/validators/run_all.py --session "_campaigns/<pc>/data/session_0001" --devroot "development"
   ```
3. **Open a chat with your AI GM** and paste the **System Prompt** from `development/prompts/system_prompt_play.txt`.  
4. **Paste the “Opening Script”** from `development/prompts/opening_script.txt`. Follow the AI’s lead.  
5. **Log as you go** in the session stubs (beats, relationships, deltas, notes). Keep numbers small and human.  
6. **When the Fold completes**, switch into the regular **Daily Loop** (see `development/docs/military_life_loop.md`) and fly.

---

## What the AI GM Must Do Every Turn
- **Scene Setup** *(short)* → **2–3 micro‑choices** → **outcome** (success/mixed/fail) → **log suggestions**.  
- Maintain background **plots & clocks**; pull faces from the **Refugee Pool**; respect **safety**.  
- Keep you **choosing**; never roll without meaning; narrate like a documentary camera.

---

## Quick Links
- **Cinematic Intro Pipeline** — `development/docs/cinematic_intro_pipeline.md`  
- **Refugee Pool Engine** — `development/docs/refugee_pool_engine.md`  
- **Squadron Ops** — `development/docs/squadron_ops.md`  
- **Military Life Loop** — `development/docs/military_life_loop.md`  
- **Downtime Engine** — `development/docs/downtime_engine.md`  
- **Alien Encounters** — `development/docs/alien_encounters.md`

Fly it like it’s the last clear night. Write your dead. Keep the lanterns lit.
