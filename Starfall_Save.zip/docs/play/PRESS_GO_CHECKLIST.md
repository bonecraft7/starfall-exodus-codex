# Press GO Checklist (fast)
- [ ] Session folder created and stubs copied
- [ ] Validators clean or warnings understood
- [ ] System Prompt pasted
- [ ] Opening Script pasted
- [ ] Refugee picks logged
- [ ] First beat saved
