# Integration Index
- **Cinematic Intro** → refugees + survival → Kuiper → Fold
- **Refugee Pool** → uplift tracks → vacancies → assignment
- **Squadron Ops** → CAP, scramble, comms, tactics, emergencies
- **Military Life Loop** → duty menus, investigations, inspections
- **Downtime** → activities, companions, recovery, souvenirs
- **Alien Encounters** → posture/ROE, trust, arcs, species packets
