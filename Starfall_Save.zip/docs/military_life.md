# Military Life Loop — Final Draft (v1)

> **Scope:** Day-to-day rhythm for a *Thronebreaker* starfighter **officer**. Sustainable structure the GM can drop in between episodes.  
> **Tone:** Steel routine under neon grief—banter, boredom, drills, and sudden terror.

---

## 0) Design Goals
- **Authentic cadence:** recognizable rotations (CAP, training, duty, standby) so the ship feels *lived-in*.
- **Character-first:** every routine is a chance to reveal bonds, rivalries, and coping habits.
- **Low → High → Low:** quiet scenes earn the spikes; after action, let characters breathe.
- **Always feed the engine:** routine scenes should tick **Fleet Clocks**, **Relationships**, and seed **side-plots**.

---

## 1) Daily / Watch Structure (Generator)
Use this to sketch a “day” when needed. Roll or pick.

| d6 | Watch Skeleton | Notes |
|---:|---|---|
| 1 | **CAP → Debrief → Duty → Standby** | Classic ops day. |
| 2 | **Training (Sim) → Duty → CAP → Debrief** | Performance evals mid-shift. |
| 3 | **Duty (OOD/Brief) → Standby → CAP → After-hours** | Night CAP; sleepy nerves. |
| 4 | **Maintenance Assist → Training → Standby → Ceremony** | Promotion/memorial or awards. |
| 5 | **Standby (Ready Room) → CAP Scramble → Debrief → Duty** | “Hurry up and wait” plus surprise. |
| 6 | **Leave (Short) → Recall → Duty → CAP** | Day-off interrupted; resentments simmer. |

> **Standing Orders:** Fleet must maintain **4 fighters on CAP** at all times. Every officer logs **2 blocks** of either CAP/Training/Duty per day unless injured.

---

## 2) Scene Types & Running Notes

### 2.1 Combat Air Patrol (CAP)
**Composition:** 2-ship or 4-ship element; cross‑wing mixing is common.  
**Beats to hit:**
- **Chatter** (see table) → **Situation** (minor/major) → **Resolution** → **Debrief hooks**.
- On quiet CAPs, let two *personal topics* surface; log **Relationship beats**.

**Chatter Topics (d8):** 1) food rations; 2) trashy soap recap; 3) wagers; 4) superstition; 5) memorial talk; 6) music recs; 7) dream fragments; 8) shipboard rumor.

**Incidents (roll 1):**
- **Minor (d10):** 1 sensor ghost; 2 debris cloud; 3 lifeboat ping; 4 civilian skiff drifting; 5 comms dropout; 6 radiation flare; 7 fuel trim warning; 8 micro‑meteor pitting; 9 refuel drone hiccup; 10 masked transponder.
- **Major (d10):** 1 unknown contact; 2 pirate shadow; 3 Ophidarch probe; 4 boarding skiff; 5 minefield remnant; 6 reactor leak on civvy; 7 med-evac escort; 8 rogue AI buoy; 9 gravity shear; 10 “ally” turns tense.

**Resolution:** Use **Conflict/Vehicle** engines; outcomes flow to **Fleet Clocks**.

---

### 2.2 Ready Room Standby
**Mood:** Cards, vids, coffee, gallows humor. Someone always naps badly.  
**Micro‑events (d8):** 1 prank; 2 heartfelt confession; 3 rumor pamphlet; 4 surprise inspection; 5 lottery for leave slots; 6 broken coffee machine; 7 pilot returns shaken; 8 flight surgeon checks vitals.

---

### 2.3 Training (Sim / Range)
**Forms:** dogfight sim trees, formation drills, weapons quals, emergency procedures.  
**Tests:** Interface/Reflex; note **Complications** as training scars (temporary -1 on next similar task).  
**Hooks:** rival outperforms you; trainee ace emerges (candidate for **Refugee Promotion**).

---

### 2.4 Duty (Officer)
Pick one:
- **OOD-Assist:** logbook, hangar flow, clearance codes; confront a signature irregularity.
- **Brief/Debrief Officer:** deliver intel packet; handle a pilot who lies by omission.
- **Liaison (Civ Council):** calm a vendor dispute; ration math angers a crowd.
- **Investigation:** missing part; black market whispers; a tool tag doesn’t match.
- **Escort / Shuttle:** fly a VIP or med case; awkward small talk at 2 AU.

---

### 2.5 Deck / Maintenance Assist
Wrench time with crews; talk shop.  
**Complications:** stripped bolt; spilled coolant; crewman refuses med check; a name carved into a panel.

---

### 2.6 Ceremonies
- **Memorial:** folded flags, names read, flight helmets lined like skulls; choose who speaks.
- **Promotion/Award:** applause that rings hollow today; jealous side‑glances.
- **Rite:** squad superstition (lucky token, hymn, chalk mark on the deck).

---

## 3) Scramble Protocols (Quick Card)

| Code | Trigger | Steps | Failure Risks |
|---|---|---|---|
| **ALPHA** | Confirmed hostile vector | klaxon → suit → hot ladder → launch < 180s | launch collision; gear left behind; comms sync error |
| **BETA** | Unknown contact / escort | alert → staged suit → controlled launch | escalation via mis-ID; PR fallout |
| **GAMMA** | SAR/Med-evac | med brief → load pod → gentle launch | patient loss; tug collision |
| **DELTA** | Internal spillover (riot, fire) | stand down fighters → officer duty re-task | morale hit; late to real threat |

> Use **Vehicle** + **Social/Authority** tests. On **Complication**, add **Hangar Hazard** or **ROE confusion**.

---

## 4) Deck Micro-Hazards (d8)
1 fuel spill; 2 unsecured crate; 3 overtorque wrench; 4 coolant leak; 5 miswired panel; 6 forklift kiss; 7 helmet HUD glitch; 8 angry junior.

---

## 5) Outputs (Deltas to write)
- `beats.json` → each scene summarized with quotes & outcomes.
- `relationships.json` → CAP chatter (+/-), rival spikes, mentorship flags.
- `character_sheet_delta.json` → fatigue, minor injuries, training scars.
- `equipment_deltas.json` → lost/issued, personal tokens, patched gear.
- `notes.md` → gossip, callsign lore, memorial names.

---

## 6) Integration Map
- **Plot Engine:** CAP Majors can escalate into episodes; Duty scenes seed mysteries/politics arcs.
- **Refugee Pool:** spot talent in Training/Deck; trigger **PROMOTE**.
- **Downtime Engine:** convert Standby aftermath to off‑duty scenes (drinks, gym, prayer, dates).
- **Fleet Clocks:** CAP success boosts **Fighter Strength**; Duty ration fights hit **Morale**.

---

## 7) GM Prompts (Drop‑ins)
- *“You’re ten minutes into boredom when the room decides to laugh—why?”*
- *“On approach, you notice something off in your wingman’s voice—what?”*
- *“A civilian says you promised something you didn’t. How do you prove it?”*
- *“Name a ritual you do before every launch. Who mocks it?”*
- *“What’s written under your seat cushion?”*

---

## 8) Example Day (Worked)
- **Morning:** Ready Room (prank war; you get coffee on your jumpsuit).  
- **Midday CAP:** Minor—lifeboat ping; escort it home; you and Rival trade barbs (Rel -2/+1).  
- **Duty:** Debrief Officer—pilot omits a near‑collision; you push, he snaps; log a **Complication**.  
- **Evening:** Memorial—three helmets, silence; you add a name to the wall; **Morale -1**, **Bond +2** with your section.  

---

## 9) Data Hooks (to be implemented in JSON)
- `military_life_events.json` → scene tables, hazards, prompts (keys above).
- `cap_incidents.json` → minor/major incident templates with tests/outcomes.
- `duty_assignments.json` → OOD/liaison/investigation seeds & consequences.
- `ceremonies.json` → memorial/promotion scaffolds.
