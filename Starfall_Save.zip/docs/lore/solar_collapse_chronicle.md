# Solar Collapse Chronicle — The 72‑Hour Fall (Final Draft v1)

> **Canon:** The Ophidarch Seraphate annihilated ~98% of Terrans in **72 hours**. This document is the fleet’s compiled record—news cuts, pilot logs, decrypted distress calls, and survivor testimonies—curated for GM use and AI lookup.  
> **Use:** Pull vignettes during intros, memorials, politics, and mystery arcs. Tie outcomes to Fleet Clocks and relationships.

---

## Timeline Overview
**Hour 0–6 — First Shadow**  
- Sudden mass‑arrivals in high orbit above major bodies. Gravitic moans; sensor blindness; comms desync.  
- Early strikes: defense constellations blink out; AR networks flood with emergency banners.

**Hour 6–12 — Orbital Choke**  
- Planet‑wide jamming and power cascades. Shipyards and elevators targeted first.  
- Precision “spallation” bursts—hulls sandblasted, stations vented, civilians scattered into vacuum.

**Hour 12–24 — Planetfall Fire**  
- Planet‑cracker lances and kinetic sieges. Evac funnels jam; shuttles collide; cities dim.  
- Refugee traffic flees rimward; pirates and doomsday cults bloom in the chaos.

**Hour 24–48 — The System Breaks**  
- Moons shoved off safe orbits; ring systems stirred into knives.  
- Jovian and Saturnian habitats collapse; Mars is glassed in ribbons; Luna bleeds air like a flute.

**Hour 48–72 — Last Light**  
- Scattered convoys reach the **Kuiper Belt**. The *Thronebreaker* calls the rag‑fleet home.  
- Starfighters die on the rim buying minutes. The **Eldritch Fold** tears the armada elsewhere.

---

## Vignettes by Region (Pull & Play)

### Earth / Luna
- **Luna: “Market Under Frost.”** Lanterns sway in low‑g; then all AR signs cut at once. A hull like a continent eclipses the dome. The glass crawls with frost as pressure leaks. Someone laughs once—high and thin—then the sirens swallow it.  
- **Earth: “Terminal C.”** A child drops a plastic ship that skates forever across the polished floor. Above the skylights, a latticework of fire unthreads the sky lanes. Security shouts are swallowed by a descending hush as if the air is holding its breath.  
- **Defense Cut:** Orbital laser arrays go **dark** in a neat ring, one after another, like candles pinched by an invisible hand.

**Assets Lost (early):** Lagrange shipyards, 3 of 5 lunar elevators, 70% of Earth’s orbital constellations, a third of Luna’s domes.

---

### Mars & Belt
- **Mars: “Glass Stripes.”** Lines of white heat rake the dust. Cities shelf into vitrified canyons; highways look like sutures. The thin wind sings in broken hangars.  
- **Ceres: “Spill of Beads.”** Cargo spheres rupture; frozen water pearls drift, each reflecting the last sunrise. Workers in orange suits push them like herders until the next blast turns them into hail.  
- **Belt Evangelist:** A pirate preacher declares the end of weight; his ship is later found empty but for a looping sermon.

**Assets Lost:** Utopia Planitia yards, Phobos tether, 40+ belt spin‑habs, the Tylium Reserve at 12‑Psyche.

---

### Jupiter & Saturn
- **Europa: “The Red Garden.”** A lab’s under‑ice lights blur; brine clouds violet, then a crack yawns upward. The sea exhales an antique smell as pressure fails.  
- **Ganymede Anchor:** The magnetic anchor coughs once and dies; half the stations drift like cut lanterns, colliding softly until sparks turn into screams.  
- **Saturn: “Knives in the Ring.”** Something stirs the rings; the fine ice wakes and scythes across the orbital lanes. Habitats peel open like fruit.

**Assets Lost:** Jovian fuel depots, 11 major habitats, Saturnian ring towns, Helene shipyard, Gateway Station.

---

### Uranus, Neptune & Beyond
- **Titania: “The Quiet Crowd.”** Dozens stand in helmets out on a blue‑black plain listening to the creak of the sky. The first probe falls like a star and keeps falling through them.  
- **Triton: “The Whistle.”** A vent field starts to sing; towers of ice shear under tidal shudder. The far horizon blooms with a lensing arc—the enemy folding more in.  
- **Scattered Disk:** Ghost beacons in the Kuiper—some human, some bait.

**Assets Lost:** Neptune scoops, outer depots, cryo‑labs, observatory webs.

---

## Ophidarch Tactics (Recognize & Reuse)
- **Mass‑Fold Saturation:** Arrive in layered shells to overwhelm sensor fusion and command tempo.  
- **Gravitic Spallation:** Micro‑grit blasts that flense hulls and habitats without classic explosions—silent, total.  
- **Blackout Nanoclouds:** EM‑hunger fogs that eat power margins and make batteries lie.  
- **Probe Gardens:** Seed the flanks with small “seraph” probes. If ignored, a larger mouth arrives.  
- **Planet‑Cracker Lances:** Not to crack the core—just to **write** on the crust; lines scorch supply and spirit.

Use these as **complications** in CAP, Duty, Crisis, and Mystery episodes.

---

## Casualty & Refugee Ledger (Abstracted for Play)
- **Population Loss:** ~98% in 72 hours. Represent as **Morale floor** and survivor scarcity.  
- **Refugee Flow:** At Kuiper rendezvous, **tens of thousands** across 30–80 civilian ships.  
- **Fleet Formation:** 1× Battleship (*Thronebreaker*), ~9× other military hulls, many damaged; civil craft from luxury liners to hab barges.

Use the **Refugee Pool Engine** to spotlight individual stories from this ocean of loss.

---

## GM Pulls (Drop‑in Prompts)
- *“Name a smell you still can’t forget from the hour the sky broke.”*  
- *“Whose voice did you hear over the open channel saying ‘I’m still here’—and then nothing?”*  
- *“What object from before the Fall do you still carry, and why haven’t you thrown it away?”*  
- *“What rumor about the Seraphate do you secretly believe?”*

---

## Hooks into Systems
- **Cinematic Intro:** Pick any vignette as the first beat; tie extraction to regional chaos.  
- **Plot Engine:** Crisis (*Fuel*, *Power*) and Mystery (*Ghost Ship*, *Hidden Message*) seeds slot into Hour 24–72 beats.  
- **Downtime:** Memorial scenes reference these entries; music nights resurrect pre‑Fall songs.  
- **Military Life:** CAP chatter mines eyewitness scraps; ceremonies name the fallen places.

---

## Appendix: Fallen Places (Sampling Table)

| d20 | Place | Fate |
|---:|---|---|
| 1 | Gate Nine Elevator (Luna) | Severed at 30km; ladder fall like rain. |
| 2 | Utopia Planitia Dock 12 (Mars) | Vitrified; hulls half‑melted together. |
| 3 | Tylium Reserve 12‑Psyche | Breached; ore field now shrapnel. |
| 4 | Europa Lab V‑13 | Flooded under red‑violet brine. |
| 5 | Ganymede Anchoryard | Drift collision cascade. |
| 6 | Helene Yard (Saturn) | Ring‑knife storm; open to stars. |
| 7 | Gateway Station | Atmosphere boiled off; adrift. |
| 8 | Triton Beacon Net | Fold‑flare fried rectennas. |
| 9 | Green Calder Barge | Gardens stripped; frames intact. |
| 10 | Saffron Tide Liner | Party → panic → rescue ferry. |
| 11 | Ceres Halo 3 | Shattered into pearl hail. |
| 12 | Phobos Tether Ring | Cut in three; slings debris. |
| 13 | Archimedes Dome (Luna) | Frost‑webbed, evacuated. |
| 14 | Jovian Fuel Stack 7 | Burned blue then black. |
| 15 | Titan Drydock A | Silent; tools still warm. |
| 16 | Ariel Listening Post | Last log is a lullaby. |
| 17 | Neptune Scoopway | Intake clogged with bones of ships. |
| 18 | Vesta Market | Prayers over ration drums. |
| 19 | SolReach Observatory | Lenses spidered; a moth in glass. |
| 20 | Terran Museum Ship “Archive Ark” | Now a tour under armed guard. |

