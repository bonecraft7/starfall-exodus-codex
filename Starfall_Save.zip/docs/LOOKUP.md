# Fast Lookup (for you + AI)

- **Start session** → `play/PLAY_START_HERE.md`
- **Run opener beats** → `game_files/data/opener/*`
- **Pick refugees** → `game_files/data/refugees/registry_merged.json` (your NPCs win)
- **City scenes** → `docs/ship/thronebreaker.md :: City in the Belly`
- **Relationships text** → `game_files/data/relationships/text_templates.json`
- **Alien contact** → `docs/aliens/first_contact.md` + `game_files/data/aliens/*`
- **Siege flashbacks** → `game_files/data/sol/*`
- **Validators** → `tools/validators/*`