# Scene Context
- **Locale**: <place> (lookup description_registry)
- **Cast**: <NPCs present + moods>
- **Objective**: <what PC wants right now>
- **Complication**: <what stands in the way>
