# Session Boot Summary
- **Player**: <name>, Archetype, Hooks
- **Ongoing Arcs**: <next beat> + clocks
- **World State**: top 5 facts (factions, threats)
- **Favorites**: <list + states>
- **Recap**: 3–5 bullets of last session
