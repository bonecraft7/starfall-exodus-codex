# Conflict Summary
- **Mode**: melee | gunfight | vehicular | starfighter
- **Stakes**: <what matters>
- **Key Tags**: cover | ECM | terrain | fear
- **Outcome (engine)**: success | mixed | failure (+ complications)
