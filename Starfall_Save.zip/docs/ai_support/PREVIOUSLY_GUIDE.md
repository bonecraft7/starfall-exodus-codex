# PREVIOUSLY_GUIDE.md
- 2–5 beats, no spoilers beyond latest deltas.
- Use cinematic brevity; 1–2 lines per beat.
- Emphasize choices, costs, and looming threats.
