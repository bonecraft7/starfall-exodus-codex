# Intimacy Behaviors (Starfall Exodus)

## Romantic (examples)
- Storm Shelter — huddled closeness in chaos.
- Shared Vow — oaths to endure together.
- Festival Flame — celebrations together.
- **(…full list + scifi/metal/EDM/refugee/mourning additions)**

## Mainstream (examples)
- Hair Pulling (Gentle).
- Blindfolded (Receiving).
- Shower Sex (steam, slippery, cinematic).
- **(…extended list)**

## Extreme (examples)
- Shattered Glass Ritual.
- Edge of Death — intimacy after near-fatal events.
- Abyss-Gaze — climax under the starfield void.
- **(…extended list)**

## Wardrobe / Underwear Styles
- Women: cheeky, boyshort, thong, g-string, bralette, demi-bra, t-shirt bra, push-up bra.
- Men: boxer-brief, Brazilian.
- Each with short descriptors for AI memory (fit, coverage, vibe).
