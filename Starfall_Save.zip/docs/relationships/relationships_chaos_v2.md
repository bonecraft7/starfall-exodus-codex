# Relationships Chaos v2 — Desire, Windows, and Consent (Final Draft v1)

> **Promise:** Make connections feel human: messy, impulsive sometimes, tender often, still respectful. This upgrade adds **states, flags, windows, and cadences** so the GM/AI can model *quiet bonds, sudden heat, jealousy spirals,* and *aftercare*—with safety.

**Integrates with:** City, Military Life, Downtime, Refugee Pool, Squadron Ops. Uses `relationships/*`, `downtime/texting_prompts.json`, and `safety/boundaries_consent.json`.

---

## 0) Core Ideas
- **State Machine:** `stranger → acquaintance → buddy|rival → friend → flirt → crush → dating → lovers` (+ forks: `complicated`, `ex`, `rival`).  
- **Flags:** `impulsive`, `casual_ok`, `drama_affinity`, `jealousy_hot`, `poly_ok`, `private`, `slow_burn`.  
- **Windows (Chaos):** short contexts that loosen cadences: **post‑scramble adrenaline, festival night, grief vigil, SABLE quiet, near‑miss survival.**  
- **Cadence:** DM/date/spice cooldowns shorten inside a **window** *if and only if* **consent** is greenlit.  
- **Consent:** Always explicit; sexual content fades‑to‑black. Power dynamics matter (see safety file).

---

## 1) Files
- `development/data/relationships/relationship_transitions.json` — states, flags, allowed jumps, chaos windows.  
- `development/data/relationships/messaging_rules.json` — DM/date/spice cooldowns, escalation ladders, window modifiers.  
- `development/data/relationships/relationship_traits.json` — personality facets (attachment, flirt style, jealousy sensitivity).  
- `development/data/relationships/text_prompts.json` — DMs (opener, apology, aftercare, flirt, suggestive, spice→fade).  
- `development/data/relationships/jealousy_rules.json` — triggers, event forms, resolution paths.  
- `development/data/relationships/conflict_resolution.json` — apology/boundary renegotiation playbook.  
- `development/data/safety/boundaries_consent.json` — consent checks & power‑dynamic rails.

---

## 2) Negative‑to‑Heat Path (Enemies → Sparks)
Some people kiss after they argue. Enable **conflict‑to‑chemistry** only when:
- At least one has `drama_affinity` **and** the other is not `slow_burn`.  
- Both pass a **Boundary Check** (greenlight) and there’s **privacy**.  
- A **Chaos Window** is active (e.g., *festival night* or *post‑scramble adrenaline*).  
If all true: allow jump `rival → flirt` or (rare) `rival → hookup` (fade‑to‑black). Apply **aftercare scene** next turn.

---

## 3) Jealousy
Jealousy can be **hot** for some; harmful for others. Use `jealousy_rules.json` to stage: **spark → choices → outcome**. It should *never* isolate the PC from all support or become abusive. Always offer **repair** scenes.

---

## 4) Messaging & Sexting
Sexting escalates only with **flags + consent + window**. Ladder: **playful → suggestive → explicit fade (off‑screen)**. Use short DMs; log **feelings** not details.

---

## 5) GM Macros (conceptual)
```
REL.DM(npc, type="opener|flirt|aftercare|apology|suggestive|spice", window?)
REL.WINDOW(open="post_scramble|festival|grief|sable|near_miss", duration_slots=1)
REL.ESCALATE(npc, to="flirt|date|kiss|hookup", require=consent_green)
REL.JEALOUSY(npc, trigger="press_sighting|favoritism|ex_seen")
REL.REPAIR(npc) -> apology + boundaries reset
```
Write **session deltas only**. Use **Downtime Engine** for dates & leave scenes.

---

## 6) Safety Rails
- Officers do not coerce; avoid quid‑pro‑quo.  
- Consent token required for **kiss/hookup**.  
- **Fade‑to‑black** at intimate steps.  
- Offer **aftercare** beats after big feelings (jealousy, fight, hookup).

Love should feel like living—messy, but kind.
