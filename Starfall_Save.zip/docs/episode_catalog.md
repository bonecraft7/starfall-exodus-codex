# Episode Catalog — Expansion Pack (v2)

> 12 new seeds were added. Use with Plot Engine selection.


## Fleet Crisis

- **Thin Blue** — Potable reserves crash after a recycler fault. Ice haul or dehydration—and rumors of hoarding.  (`fc_water_thin_blue`)
- **Strike on the Line** — A key industry (miners or recyclers) stops work over safety and pay; jumps threatened.  (`fc_strike_on_the_line`)

## Mystery Paranoia

- **We Dreamed the Same Sky** — Crew across ships report identical dreams of a place that should not exist.  (`myst_shared_dreams`)
- **Passwords in the Walls** — Intercoms whisper correct passcodes no one admits sending. Security or something stranger?  (`myst_passwords_in_walls`)

## External Threat

- **The Ship That Smiled** — A derelict transmits a friendly beacon; it’s a Q‑ship with hidden guns.  (`ext_q_ship_smile`)
- **Boarders Like Dust** — Micro‑drones—‘mites’—infiltrate through vents; they’re building toward something.  (`ext_boarding_mites`)

## Character Drama

- **Ace of Spades** — A hot‑shot rival pilot pushes you into a public sim duel—and the wing picks sides.  (`cd_ace_of_spades`)
- **Whispers in the Officers’ Mess** — A rumor claims you bent rules for a favorite; careers and trust hang in balance.  (`cd_officers_mess_whisper`)

## Romance

- **Old Flame on the Ark** — An ex from before the Fall turns up among civilians; sparks, regrets, or closure.  (`rom_old_flame_ark`)
- **Kiss or Kill** — A fierce argument with a rival teeters into chemistry—if boundaries allow.  (`rom_kiss_or_kill`)

## Diplomacy

- **The Dissident Choir** — Kaari dissidents seek asylum after a guild dispute; accepting them strains trust with their Confluence.  (`dip_kaari_dissident_choir`)
- **Graves and Gifts** — Ferrox rites claim a wreck with human remains; they demand payment or permission to cut.  (`dip_ferrox_graves_and_gifts`)