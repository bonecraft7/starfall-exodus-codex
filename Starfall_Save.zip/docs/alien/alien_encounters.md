# Alien Encounter Guide — Intensity, Etiquette, Join‑Fleet (Final Draft v1)

> **Contract:** *Second contact is intense.* Humanity’s first brush was annihilation by the **Ophidarch Seraphate**. Every other contact is staged as a **major plot event**—even the friendly ones. Proceed wary, curious, and cinematic.

**Integrates with:** Plot Engine (diplomacy arcs), Squadron Ops (posture/ROE), City (visas/etiquette), Refugee Pool (asylum), Military Life (orders & investigations), Downtime (leave on allied ships).

---

## 0) When to Roll a Contact
- **Rare by default**: at most **one contact arc per 3–5 sessions** unless the story demands it.  
- Trigger via Plot seeds, deep‑space leads, or **fold side‑effects**. Never casual.

Use `data/alien/contact_arc_seeds.json`.

---

## 1) Intensity Dials (1–5)
1. **Cautious Echo** — distant hails, no close approach.  
2. **Wary Parley** — neutral zone, formal gestures.  
3. **Close Handshake** — escort range; gifts or data trade.  
4. **Friction** — tests of nerve, protocol clashes, or pirates sniffing.  
5. **Knife‑Edge** — misfire, trap, or moral test under time pressure.

> **Second‑Contact Bias:** the **first non‑Ophidarch** species you meet this campaign must start at **3+**. File: `data/alien/first_contact_protocol.json` (`second_contact_bias`).

---

## 2) Protocol Flow (Fleet)
**Detect → Classify → Hail → Handshake → Parley → Decision → Log.**  
- Posture sets from WHITE/AMBER/RED/SABLE (see matrix).  
- Mercy staged for **SAR**.  
- Weapons stay **safed** unless **RED** or fired upon.  
- Chaplain/Diplomacy team rides the shuttle; pilot is liaison.

Files: `first_contact_protocol.json`, `posture_matrix.json`.

---

## 3) Etiquette Packs
Species packets define **greetings, taboos, trust clues, gifts, and terms**. Use **Kaari** (Confluence guild culture) and **Ferrox** (grave‑rite salvagers) as examples. Unknowns use the **Generic Unknown** pack until profiled.

File: `etiquette_packs.json` and `species_packets/*.json`.

---

## 4) Join‑Fleet Rules (Provisional)
Allies may sail with the armada under **provisional charter**:
- **Handshake:** shared map data, comms standard, SAR pledge.  
- **Visas:** crew IDs; city permits; etiquette class.  
- **ROE:** compatible posture codes; no stealth inside civilian lanes.  
- **Trust Clocks:** 0–6; progresses with good faith, regresses on fails.  
- **Arcs:** trade, cultural exchange, military drill, or asylum politics.

File: `join_fleet_rules.json`, `trust_clocks.json`.

---

## 5) Scene Beats & Prompts
Use `contact_events.json` to stage **opener → test → choice → outcome** beats. Tie outcomes to **trust clocks**, **morale**, **downtime leave**, or **new Plot seeds**.

---

## 6) Safety & Tone
- Keep **R‑rated in scale**, not in gore. No xenophobia porn; critique through **choices**, not slurs.  
- Respect **consent** even in cultural rites; use interpreters.  
- Offer **repair** scenes after missteps (apology, gift, shared work).

Light the dark with curiosity. Keep a hand on the throttle.
