# Military Life Loop — Officer Duties, Investigations, Downtime (Final Draft v1)

> **Contract:** You are a commissioned pilot‑officer aboard the **Thronebreaker**. Between sorties, you live inside a cycle of **duty, training, inspections, investigations, and brief breaths of life**. This pack gives you a **tight loop** the GM/AI can run any day with zero prep.

**Integrates with:** Squadron Ops, City Builder (New Arcadia), Refugee Pool, Relationship Chaos, Alien Encounters, Plot Engine, Cinematic Intro.

---

## 0) The Daily Cycle (suggested scaffolding)
| Phase | Window | Menu |
|---|---|---|
| **Stand‑Up** | 06:00–08:00 | Briefs, handovers, CAP set, safety notes. |
| **Duty Block A** | 08:00–11:00 | CAP / Deck OOD / Inspection / Training Sim. |
| **Mess + Admin** | 11:00–13:00 | Reports, counseling, mail, quick City errand. |
| **Duty Block B** | 13:00–17:00 | Investigation legwork / Eldritch escort / Repairs. |
| **Ready‑Room** | 17:00–20:00 | Scramble posture, chatter loops, sim gauntlets. |
| **Downtime Window** | 20:00–24:00 | City scenes, dates, volunteer shift, quiet, leave (if granted). |
| **Graveyard** | 00:00–06:00 | SABLE drills, surprise inspections, late‑night calls. |

> Adjust with posture **WHITE/AMBER/RED/SABLE** and current Plot or CAP schedule.

---

## 1) Duty Menus
Pick **one** per block (or roll). See JSON for prompts & hooks.
- **CAP Flight** — see Squadron Ops.  
- **Deck Officer of the Day (OOD)** — safety sweeps, turnarounds, Greenie Board.  
- **Inspection** — mess, armory, clinic, city perimeter stalls.  
- **Training** — sims & checkrides; tutor a junior.  
- **Investigation** — triage a complaint or incident (framework below).  
- **Eldritch Escort** — pilot/liaison for the Division; safety rails on.  
- **Admin & Care** — counseling, letters, memorial duty.

JSON: `data/military/life_loop/officer_tasks.json`

---

## 2) Investigations (Officer Conduct / Incidents)
Use the **framework**: **Intake → Triage → Leads → Legwork → Confrontation → Resolution**. Generate a **casefile** from the template and write deltas only.

- Evidence tokens: **logs**, **witness**, **physical**, **surveillance**, **rumor**.  
- Outcomes: **restorative**, **disciplinary**, **referral**, or **unsolved (clock)**.

JSON: `data/military/life_loop/investigation_framework.json`, `templates/casefiles/investigation_casefile.json`  
Incident generators: `data/military/life_loop/incident_types.json`

---

## 3) Inspections
Short checklists with **findings** that can spark scenes: missing PPE, forged permit, unsafe wiring, contraband, morale rot. Findings can feed **Plot Engine** or **Refugee Pool uplift**.

JSON: `data/military/life_loop/inspection_tables.json`

---

## 4) Downtime Interleaving
Every day offers a **Downtime Menu** appropriate to posture, with hooks into **City** (Hydra Noodles, Velvet Drape, Quiet Orbit), **Leave** locations (ally ships, cruiseliner hot springs), or **Volunteer** shifts. Respect **curfews** and **permits**.

JSON: `data/military/life_loop/downtime_menus.json`, `data/military/life_loop/leave_locales.json`

---

## 5) Fatigue & Stress
Track **fatigue** (duty overdraw, RED posture) and **stress** (incidents, CAP). Use small deltas to `character_sheet_delta.json`. Recovery through **sleep**, **quiet scenes**, **counseling**, or **leave**.

JSON: `data/military/life_loop/fatigue_stress.json`

---

## 6) Eldritch Babysitting
Escort or fly for the **Eldritch Division** during investigations or rituals. Safety rails: no lethal exposure, clear aborts, Mercy on deck. Treat as **mystery/paranoia** episodes seeded lightly.

JSON: `data/military/life_loop/eldritch_babysitting.json`

---

## 7) Orders Generator & Duty Scenes
Pull a crisp **orders card** when Plot is quiet. Sprinkle **micro‑scenes** (coffee broken, letter owed, fight to break up) to keep life human.

JSON: `data/military/life_loop/orders_generator.json`, `data/military/life_loop/duty_scenes.json`

---

## 8) Logging
- `beats.json` — scene titles + outcomes (CAP/Investigation/Inspection/Downtime).  
- `relationships.json` — wing bonds, rivalries, aftercare, City allies.  
- `equipment_deltas.json` — faults found, gear issued.  
- `notes.md` — names, debts, promises made.

Fly your watch. Keep them safe. Earn your sleep.
