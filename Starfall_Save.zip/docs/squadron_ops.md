# Squadron Ops — CAP, Scramble, Deck & Ready‑Room (Final Draft v1)

> **Contract:** Four wings (**Rook, Vesper, Mercy, Talon**) guard the rag‑fleet. There is always a **4‑ship CAP** in the black. Ops flex with posture codes **WHITE/AMBER/RED/SABLE**. This pack gives you procedures, chatter, and JSON tables to run sorties with zero prep.

---

## 0) Roles & Culture
- **Lead / Two / Three / Four** — standard 2‑element pairs. Lead calls, Two watches; Three/Four flex screen.  
- **Call‑signs** stick; earn them in air or in rumor. Log origins in session deltas.  
- **Mercy Wing** owns **SAR/medevac**; **Vesper** hits hard; **Rook** screens; **Talon** fills where needed.

---

## 1) CAP Pattern (Always On)
- **Baseline:** 4‑ship **Box** or **Ring** at 15–25 km escorted lanes. Shift = **90 minutes**; RTB, fuel, debrief, next flight preps.  
- **WHITE:** 4‑ship. **AMBER:** 8‑ship (two boxes, layered). **RED:** as many as flyable. **SABLE:** 2‑ship dark CAP (EM low).  
- **Hand‑off:** new CAP checks in with **“On station, angels, fuel, stores.”**

JSON: `data/military/cap_ops/cap_schedule.json`

---

## 2) Scramble Procedure (Rook/Vesper/Talon)
**Readiness:** 5/2/1 minutes mapped to posture; deck status on **Green/Amber/Red**.  
**Flow (short):**  
1. **Horn/Codeword.**  
2. **Brief over taxi.** Vector & ROE.  
3. **Cat/Launch.** “**Fangs safed**” until **RED** or **fired upon**.  
4. **Intercept Profile** (see §4).  
5. **RTB or Pursuit** by ROE; **Mercy** staged for SAR.

JSON: `data/military/cap_ops/scramble_procedure.json`

---

## 3) Comms & Chatter
- **Brevity:** concise, human. “**Tally**” (see target), “**No joy**” (no contact), “**Winchester**” (ordnance empty), “**Bingo**” (fuel), “**Punch‑out**” (eject).  
- **CAP Confessional Loops** keep life breathing on quiet watches: cards, petty gossip, grief, dare‑promises.

JSON: `data/military/cap_ops/comms_brevity.json`

---

## 4) Intercept & Tactics Profiles
Use prewritten **profiles** for bogey, raider pack, drone swarm, micro‑mite cloud, and Q‑ship traps. Each profile lists **formation**, **ECM**, **weapons**, **abort**, and **Mercy** triggers.

JSON: `data/military/cap_ops/tactics_profiles.json`

---

## 5) Deck Turnaround (Greenie Board)
Checklist for **launch / recovery / post‑flight**; damage codes, hot faults, and safety barks. Short random **Deck Hazards** table for color.

JSON: `data/military/cap_ops/deck_turnaround.json`

---

## 6) Ready‑Room Scenes
Brief, debrief, the eternal waiting. Soap‑opera beats, rumor seeds, sim gauntlets, card games, and TV noise. Hooks into **Relationship Chaos** and **City** systems.

JSON: `data/military/cap_ops/ready_room_scenes.json`

---

## 7) Emergencies & SAR (Mercy Wing)
Lost‑comms, flameout, hydraulic failure, ejection tree, **SAR flow** for Mercy. Uses **WHITE/AMBER/RED/SABLE** integration and **Trust** with alien allies (if present).

JSON: `data/military/cap_ops/emergency_procedures.json`

---

## 8) Loadouts & ECM
Per‑wing **default loadouts**, jamming/anti‑jam play.  
JSON: `data/military/cap_ops/loadouts.json`, `data/military/cap_ops/ecm_jamplay.json`

---

## 9) Logging
- **beats.json:** scramble → intercept → RTB quotes & outcomes.  
- **equipment_deltas.json:** turnarounds, damage codes.  
- **relationships.json:** wing bonds, rivalries, aftercare.

Fly brutal, speak softly, write your dead. Then launch again.
