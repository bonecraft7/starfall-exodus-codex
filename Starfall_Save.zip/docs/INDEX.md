# Starfall Exodus — Master Index

- **Quick Start**: `play/PLAY_START_HERE.md`
- **Opener Runbook**: `play/OPENER_RUNBOOK.md`
- **Rules (PbtA Quickref)**: `docs/rules/AT_THE_TABLE_QUICKREF.md`
- **Starfighter Cinematic**: `docs/military/starfighter_cinematic_play.md`
- **Enemy Playbook (Ophidarch)**: `docs/enemies/ophidarch_playbook.md`
- **Thronebreaker & City**: `docs/ship/thronebreaker.md`
- **Relationships — Chaos v2**: `docs/relationships/chaos_v2.md`
- **Alien Protocols & Join‑Fleet**: `docs/aliens/first_contact.md`, `docs/aliens/join_fleet.md`
- **Solar Devastation Atlas**: `docs/sol/atlas.md`
- **Refugees**: `docs/refugees/registry.md`

**Data (game_files/data/…)**
- opener/, sol/, refugees/, relationships/, aliens/, ship/, plot/ (as added)

**Tools**: `tools/…` (validators, merge, bridges)