# Downtime Engine — Day‑Off & Leave Scenes (Final Draft v1)

> **Promise:** Between firestorms, life insists. This engine turns a **time slot** into a **scene** with **beats, companions, and consequences**—no prep required. It plays well with **City**, **Military Life**, **Refugee Pool**, **Relationship Chaos**, and **Alien Encounters**.

---

## 0) Quick‑Run Flow
1) **Pick Slot:** morning / afternoon / evening / late. Curfew & posture (WHITE/AMBER/RED/SABLE) adjust options.  
2) **Choose Activity:** from `downtime/activities.json` (or roll). Filters enforce posture, permits, costs, and cooldowns.  
3) **Companions:** use `companion_picker.json` (wingmates, City NPCs, refugees, or solo).  
4) **Scene Template:** pull a template by `scene_type` from `scene_templates.json`; mix in `random_tables.json`.  
5) **Roll Tests:** light tests per activity (`Social`, `Insight`, `Composure`, `Tools`, etc.).  
6) **Apply Outcomes:** `episodic_rewards.json` + `recovery_rules.json` (fatigue/stress/bond/morale/tokens/souvenir anchors).  
7) **Log Deltas:** `beats.json`, `relationships.json`, `character_sheet_delta.json` (recoveries), optional `equipment_deltas.json` (souvenir).

---

## 1) Time, Posture, Cooldowns
- **Slots:** morning • afternoon • evening • late.  
- **Curfew:** City closes at 24:00; Night Market requires permit.  
- **Posture:** `WHITE` = full menu; `AMBER` = trimmed; `RED` = brief scenes only; `SABLE` = candle‑quiet scenes.  
- **Cooldowns:** Activities have `cooldown_slots` to keep variety (e.g., hot springs once per 4 slots).

See `engine_config.json`.

---

## 2) Activities
Each activity lists **id, label, scene_type, locale, slot, cost, time_cost, posture, requirements, tests, outcomes, hooks**.  
Locales may be **City** locations (e.g., `loc_hydra_noodles`) or **Leave** sites (e.g., `leave_saffron_springs`).

See `activities.json`.

---

## 3) Companions
Picker rules prefer **existing bonds**, then **wingmates**, then **City NPCs**, then **refugees** with relevant tags. Chaos flags (`impulsive`, `drama_affinity`, `casual_ok`) can open **Flirt/DM** beats when consent and context allow.

See `companion_picker.json` and `texting_prompts.json`. Respect `boundaries_consent.json`. Fade‑to‑black only.

---

## 4) Scene Templates
Templates are **beats with choices**: **opener → turn → climax**, with insert points for **rumor seeds** and **relationship shifts**.

See `scene_templates.json`.

---

## 5) Leave
Allied ships/ports provide **leave locales** with unique etiquette and hooks (Kaari Aerie, Saffron Tide Hot Springs, Dark Observation Outpost).

See `leave_sites.json`.

---

## 6) Consequences & Recovery
Map small outcomes to recoveries and anchors: **fatigue‑1, stress‑1**, **bond±**, **morale±**, **souvenir** (write to equipment/notes).

See `recovery_rules.json` and `episodic_rewards.json`.

---

## 7) GM Macros (conceptual)
```
DT.PICK(slot="evening", posture="AMBER") -> activity_id
DT.COMP("activity_id") -> [npc_ids] or []
DT.SCENE(activity_id, companions) -> {beats, tests, outcomes}
DT.APPLY(outcome) -> deltas (sheet/relationships/notes)
```
> Choose sensibly; write **session_XXXX** deltas only.

---

## 8) Safety
- **No explicit sexual content.** Use **fade‑to‑black**.  
- Respect **power dynamics** and consent.  
- Allow graceful exits from dates and DMs.

---

## 9) Logging Reminders
- **beats**: title, companions, one quote.  
- **relationships**: +/‑ deltas with notes (jealousy/aftercare).  
- **sheet delta**: fatigue/stress; any small +1s.  
- **notes**: souvenirs, debts, promises.

Have a day that feels like a day—even if the sky breaks later.
