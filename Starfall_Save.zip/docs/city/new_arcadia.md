# New Arcadia — Thronebreaker Refugee City (Final Draft v1)

> **Pitch:** A protected civilian zone strung through carrier spines and hangars: lantern-lit markets, AR adverts, tea fog, and rumor. **Neo‑Tokyo** vibe by necessity. Military perimeters ring it; the deck is never truly quiet.

**Role in play:** The City is a living stage for **Downtime**, **Investigations/Inspections**, **Refugee Pool uplift**, **Romance/Chaos**, and **Alien Leave visas**. Never static—shops open, stalls fold, a mayor begs for patience.

---

## 0) Quick Facts
- **Name:** New Arcadia (NA‑01 Civilian Zone)  
- **Interim Mayor:** **Meera Kazemi** (npc_meera_kazemi), elected by stallholders & ship crews.  
- **Population:** ~34,000 and rising (flux with rescues).  
- **Zones:** Lantern Market, Admin Spine, Quiet Orbit (tea & memorial), Echo Row (music/bar strip), Velvet Quarter (consent‑forward adult venues), Patchwork Clinic, Housing Blocks H1–H8.  
- **Perimeters:** Inner cordon (MP checkpoints), Outer cordon (blast doors), Emergency lanes (red).  
- **Curfew:** 24:00; Night Market extension by permit.

Files: see `development/data/city/*` for districts, venues, permits, patrols, events, NPCs, and map.

---

## 1) Using the City in Scenes
- **Downtime:** pick an activity (Hydra Noodles, Echo Bar, Quiet Orbit, Velvet Drape, Night Market).  
- **Inspections:** run `inspection_tables.json` (missing PPE, forged permit, unsafe wiring).  
- **Investigations:** pull `incident_types.json` (contraband, blackout, scuffle) with City locations.  
- **Refugee Uplift:** spot talent at stalls, clinic, logistics lanes.  
- **Romance/Chaos:** use **windows** (festival night, grief vigil, SABLE quiet). Respect consent rails.

---

## 2) Growth & Clocks
- **City Stability (0–6):** supply, order, morale.  
- **Economic Pulse:** tokens in circulation; permit revenue; barter health.  
- **Crisis Clocks:** blackout chain, rumor fever, crowding boil.  
Advance via **repairs, fair policing, festivals**. Regress via **predation, neglect, red posture**.

Data: `city_clocks.json`, `economy.json`.

---

## 3) Permits & Curfew
- **Stall Permit**, **Night Market Extension**, **Adult Venue** (consent-forward policies), **Busker**, **Press**, **Alien Visa Class**.  
- Curfew exceptions only by permit. MPs enforce fairly; paperwork feeds plots.

Data: `permits.json`.

---

## 4) Districts & Venues
See data for **districts** and **venues** with hooks and owners. Anchor spots include:
- **Hydra Noodles** (Kyou Tan) — `loc_hydra_noodles`  
- **Echo Bar** (Luca Vance) — `loc_echo_bar`  
- **Quiet Orbit** (Brother Jun) — `loc_quiet_orbit`  
- **Velvet Drape** (Sable Inez, consent-forward) — `loc_velvet_drape`  
- **Lantern Market** (permit board) — `lantern_market`  
- **Patchwork Clinic** (triage) — `loc_patchwork_clinic`

---

## 5) Safety & Boundaries
- Civilian zone: no weapons brandished; arrests are last resort.  
- Adult venues are **consent-forward**; strict rules; fade‑to‑black only.  
- Respect alien etiquette zones when open.

See `data/safety/boundaries_consent.json` for global rails.

---

## 6) GM Macros (conceptual)
```
CITY.EVENT("grand_opening:velvet_drape") -> beats + rumor + permit check
CITY.PATROL("lane_red_3") -> hazard or kindness
CITY.PERMIT("stall:renewal|night_market|adult") -> paperwork + favor
CITY.RUMOR() -> pick from city_rumors.json
CITY.CLOCKS(tick="stability±1|blackout+1") -> log
```
Write **session deltas only**. Keep the City human: favors, apologies, noodles.

---

## 7) Logging Reminders
- beats.json — scene title + one smell/sound color.  
- relationships.json — city allies, favors owed.  
- character_sheet_delta.json — stress/fatigue, small morale bumps.  
- notes.md — souvenirs, names of stallholders, IOUs.
