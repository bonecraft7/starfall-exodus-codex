# Alien Encounter Framework — Final Draft (v1)

> **Purpose:** Make **rare** first contacts feel seismic—even when friendly—and give the GM an actionable playbook: posture, translation, trust, arcs, and fallout.  
> **Overplot Constraint:** Humanity is traumatized and hunted. Default stance is **Defensive Curiosity**: open channels, guard the heart.

---

## 0) Rarity & Cadence
- **Encounter Cooldown:** Minimum **2 jumps** or **2–4 sessions** between contacts unless triggered by Plot Engine “diplomacy” flags.  
- **Event Weight:** Treat first contact as a major episode; attach a follow‑up within 1–3 sessions.  
- **Fleet Impact:** Success may allow **limited ally escort**, **trade**, or **civilian hospitality visas**.

Configurable in `alien_contact_frequency.json`.

---

## 1) Posture & ROE (Defensive Curiosity)
**Codes:** `WHITE` (distant), `AMBER` (approach), `RED` (threat), `SABLE` (unknown anomaly).

| Code | CAP | Weapons | Comms | Civilians |
|---|---|---|---|---|
| WHITE | standard 4‑ship | safed | passive listen | normal |
| AMBER | extend screen to 8‑ship | hot‑safe | active hail w/ handshake | restrict outer decks |
| RED | scramble full wings | weapons free if fired upon | terse, guarded | shelter‑in‑place |
| SABLE | minimal emissions | cold | math/visual only | blackout drills |

**ROE Notes:** No warning shots inside 10 km. Escort lanes at 15–25 km. Boarding only on explicit consent or SAR.

Defined in `alien_encounter_protocols.json`.

---

## 2) Translation & Handshakes
**Handshake Order:**
1) **Math & Physics:** prime pulses, hydrogen line, basic constants.  
2) **Visual Pictograms:** stick‑figure *us*, simple ship silhouettes, non‑weapon gestures.  
3) **Lexicon Seeds:** nouns → verbs → intent (aid/trade/seek).  
4) **Test Question:** ask/answer a trivial, falsifiable thing.  
5) **Taboo Probe:** gently test cultural taboos (see species packet if known).

Backed by `signals_lexicon.json` and `comms_playbook.json`.

---

## 3) Trust Model
`trust_score` ∈ **[-2..+3]** → Hostile, Wary, Neutral, Cautious Friend, Ally, Escort Ally.

| Score | Label | Permissions |
|---:|---|---|
| -2 | Hostile | No trade; decoy/evade; weapons ready. |
| -1 | Wary | Shadowed lanes; no close approach. |
|  0 | Neutral | Basic trade at range; escort oversight. |
| +1 | Cautious Friend | Limited dock exchange; cultural meet. |
| +2 | Ally | Convoy escort allowed; shared patrol plan. |
| +3 | Escort Ally | Temporary integration into Fleet routes. |

`alien_trust_model.json` lists **events** that move trust up/down (aid, deception, ROE breaches, gifts, rescues).

---

## 4) Encounter Arcs (Use as Episodes)
Each arc has **setup → beats → climax → outcomes**, mirroring Plot Engine style.

- **Aid Offer:** Alien convoy offers water/fuel in exchange for escort through a hazard. Risk: hidden cost or enemy tail.  
- **Cultural Exchange:** Invitations to share music/rituals with strict etiquette. Risk: taboo breach, rumor spiral.  
- **Misunderstanding:** Translation gap escalates until a choice: de‑escalate or posture.  
- **Pirate/Scav Syndicate:** Non‑aligned aliens treat the Fleet as salvage. Moral lines blur.  
- **SOS at the Edge:** Alien life pod recovered; who do we become as we help?  
- **The Price:** An ally asks for a person, a vote, or a piece of the Fold engine ritual.

See `alien_encounter_arcs.json` for structured entries.

---

## 5) First Species Packet — **Kaari Confluence** (friendly, intense)
**Physiology:** Tall, hollow‑boned bipeds; feather‑crests signal emotion; skin bioceramic scales. **Atmosphere:** oxygen‑lean, dry; tolerate ours with masks.  
**Perception:** Excellent long‑range vision; **scent‑time** (pheromone clocks).  
**Speech:** Chirp‑whistle with chorded undertones; easily rendered into tones.  
**Culture:** **Confluence** = guild‑flocks; decisions made by flight choreography and scent codes. Value **debts repaid in beauty** (craft, music, escort patterns).  
**Ships:** Ring‑hulled **sail‑carriers** using solar webs and micro‑fold glides; fighter‑perch external mounts.  
**Trade:** woven polymer sails, dry rations, memory‑scent vials.  
**Taboos:** **Do not touch the crest** without invite; **do not gift sharp steel** (seen as curse).  
**Trust Hooks:** return a small flock‑flag they lost; fly an escort pattern aesthetically (they’ll notice).  
**Intense First Contact:** They arrive **during a power brownout**, offering to “sing the grid” with resonant sails. The Deck Chief thinks it’s snake‑oil; they aren’t wrong—half ritual, half physics.

File: `species/kaari_confluence.json`

---

## 6) Second Packet — **Ferrox Guild** (scavenger cartel, dangerous “ally”) 
**Physiology:** Compact exos with magnetotactile pads; methane‑favorite suits; voices like chipped bells.  
**Culture:** Contract absolutists; salvage is **theirs** once tagged. Believe **wrecks are graves**—unless you pay the rites.  
**Ships:** Tug‑clusters with harpoon drones; cutting lamps; makeshift cannon.  
**Taboos:** Breaking a contract line is *sacrilege*; they escalate from fines → disablement → boarding.  
**Play:** Excellent uneasy partners against pirates; treacherous if hungry.

File: `species/ferrox_guild.json`

---

## 7) Integration
- **Plot Engine:** `diplomacy` and `external_threat` seeds may draw from **Kaari** and **Ferrox** arcs.  
- **Military Life:** CAP protocols map to **WHITE/AMBER/RED/SABLE**; Ready Room rumors bloom after contact.  
- **Downtime:** Cultural nights, gift exchanges, etiquette lessons, awkward romances (if allowed).  
- **Refugee City:** Temporary alien stalls, visas, and security perimeters.

---

## 8) GM Prompts
- *“What move would prove you’re not prey without sounding like a threat?”*  
- *“Which part of their ritual felt like mockery until you realized it was care?”*  
- *“What debt do you accept knowing you cannot repay quickly?”*

