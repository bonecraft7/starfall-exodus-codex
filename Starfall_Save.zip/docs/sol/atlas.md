# Solar Devastation Atlas (v1)

> **72 hours of falling sky.** The Ophidarch Seraphate erases **≥98%** of humankind across Sol in three relentless phases. This atlas gives the AI GM *playable facts* to flavor flashbacks, rumors, and strategic scarcity—**R‑rated in scale, not gore.**

**Where used:** Cinematic Intro flashbacks · Memorial scenes · Resource scarcities · Pursuit clocks · Alien diplomacy context.

---

## The 72‑Hour Shape
- **Phase I — Astrophobia (T+0→+18h):** impossible silhouettes bloom in orbit; **Black Ladder** kinetic steps fall; cities go dark; stations vent.  
- **Phase II — Siege (T+18→+48h):** **Drone Walls** bend lanes; **Ghost Nets** split comms; **Gravemill Towers** shear orbits (Luna quakes; rings groan).  
- **Phase III — Cull (T+48→+72h):** surgical strikes on shipyards, fuel nodes, food lines; evacuations harried; survivors scatter to the Kuiper rendezvous.

**Outcome:** population loss **≥98%**; industry shattered; the Armada forms around **TNS Thronebreaker** and flees via **Cathedral Drive**.

---

## How to Use in Play
- **Flash a memory** when the pilot sees a similar sky. Choose an event from `timeline_72h.json` or `destruction_events.json` and attach a sensory tell (bell, shadow geometry, wrong light).  
- **Price scarcity** using `fleet_resource_losses.json` (fuel/food/shipyard loss multipliers).  
- **Seed rumor** from `rumors_and_signals.json` then let a mission test it.  
- **Respect tone:** no graphic detail. Speak of scale, sound, silence, and choices made too fast.

---

## Files
- `development/data/sol/timeline_72h.json` — canonical timeline anchors (T+hours, locations, effects)
- `development/data/sol/destruction_events.json` — reusable event templates (type → tell → effect → counterplay → cost)
- `development/data/sol/targets_lost.json` — stations, colonies, and cities confirmed lost/abandoned
- `development/data/sol/fleet_resource_losses.json` — scarcity multipliers for episodes
- `development/data/sol/rumors_and_signals.json` — hooks for mysteries and hope

**Operator tip:** Never stack two siege engines in one scene unless you want a finale.
