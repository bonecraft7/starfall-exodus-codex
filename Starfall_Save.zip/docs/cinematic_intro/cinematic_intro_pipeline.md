# Cinematic Intro Pipeline — Slice of Life → Astrophobia → Survival ×3 → Kuiper → Intake → Fold (Final v1)

> **Contract:** Every campaign **always** opens normal: a date, a concert, a mall on the moon. Then the **sky breaks**—the Ophidarch Seraphate arrives in scale that makes the heart small. You survive **three chained trials** with 2–4 strangers (female refugees), reach the **Kuiper rendezvous**, board the **Thronebreaker**, and witness the **Fold**. Play begins after the Fold.

**Voice:** gothic‑romantic; terse in combat. **R‑rated in scale**, not gore. Consent rails on.

---

## 0) Quick Operator Flow (AI GM)
1) **Locale** — pick from `data/cinematic_intro/locales.json` and run 2–4 minutes of slice‑of‑life.  
2) **Astrophobia Event** — pull from `astrophobia_events.json`; call for **Composure**; apply stress per result.  
3) **Refugee Picks (2–4 female strangers)** — select from `refugee_selection_rules.json` using `refugees/registry*.json` if present; otherwise synthesize from rules. Give each **a skill tag** and **an origin fragment**.  
4) **Survival Chain ×3** — generate **Hazard → Social → Tech** challenges from `survival_challenges.json`; tie one beat to each refugee’s skill.  
5) **Extraction Vector** — choose a path out (shuttle, lifeboat, tug, sail‑carrier, etc.) from `extraction_vectors.json`; pay a cost (scar, loss, IOU).  
6) **Kuiper Rendezvous** — approach, losses in the lanes, the rag‑fleet in silhouette. Use `kuiper_rendezvous.json`.  
7) **Thronebreaker Intake** — ID, housing, **volunteer call**; squadrons have **vacancies**. Use `thronebreaker_intake.json`.  
8) **Fold Ritual** — describe the **eldritch engine**; apply recovery/stress effects. Use `fold_ritual.json`.  
9) **Hand Off to Play** — switch to Daily Loop / Squadron Ops. Log deltas only.

---

## 1) Logging Contract
- **beats.json** — title + 1 quote per beat.  
- **relationships.json** — refugees (new allies), bonds ±, rival seeds.  
- **character_sheet_delta.json** — stress/fatigue; fold recovery.  
- **equipment_deltas.json** — souvenirs, damage.  
- **notes.md** — debts, scars, promises.

---

## 2) Safety Notes
- Don’t revel in gore. Make fear from **scale, noise, impossible shadows**.  
- Consent rails on for intimacy; use **fade‑to‑black**.  
- Player failure is survivable unless they invite harder edges.

**Begin when the player says: “Press GO.”**
