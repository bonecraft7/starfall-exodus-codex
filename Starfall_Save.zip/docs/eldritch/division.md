# Eldritch Division — Hymns, Hands, and Quiet Bells (v1)

**Charge.** Keep the Cathedral Drive from eating us; make the sky behave long enough to get home. We are the ship’s *choir* and *mask*.

**Where it fits**
- **Axis:** *Weird* (Ops/Heart assist as needed).
- **Posture:** **SABLE** when hymns are armed; quiet lights; minimal chatter.
- **Interfaces:** ECM, navigation plates, choir rooms, Raven/Jackal escorts, Medical (scars), Chaplaincy (consent).

---

## Organization
- **Ranks:** *Acolyte → Cantor → Chorister → Liturgist → Conductor → Exarch* (see `data/eldritch/ranks.json`).
- **Teams:** *Choir* (hymns), *Hands* (ritual mechanics & artifacts), *Mirrors* (sensors & pattern recognition).

## Core Procedures
1) **ECM Hymn**
   - **Cue:** enemy patterns rise, DRADIS doubles, or CAG orders **SABLE**.
   - **Action:** pick a **motif** from `data/eldritch/ecm_hymn.json` (e.g., *Lantern Veil*, *Knife Unbinding*), roll **Weird**.
   - **Results:** *10+* veil holds; *7–9* veil flickers (choose a cost); *6‑* the bell rings wrong → mark a **Weird scar** seed.

2) **Ritual Work**
   - Pick from `data/eldritch/rituals.json` (tiered). Always obtain a **consent gate** if a living mind is the focus.
   - Roll **Weird** or as listed; on a miss, the GM picks a **taboo consequence** (`data/eldritch/taboos.json`).

3) **Artifact Handling**
   - Artifacts in `data/eldritch/artifacts.json` list **stable uses** and **taboo edges**. Most want a song, a shape, and a price.

## Safety & Consent
- R‑rated in **scale**, not gore.
- Intimacy & mind-adjacent scenes require explicit *yes*. Refusal never punishes; the world will threaten in other ways.

## Running Weird at the Table
- Use **Weird Tests** (`data/eldritch/weird_tests.json`) to frame moments: *sing in the dark*, *read a wound*, *speak with a drifting beacon*.
- Keep scenes short; two rolls max. Let the hymn shape the dogfight, not replace it.
