# Relationship Chaos Upgrade — Final Draft (v1)

> **Purpose:** Make bonds, texting, flirting, and intimacy feel human—sometimes messy, sometimes impulsive—while staying coherent for GM and AI.  
> **Contract:** Respect consent and safety. No explicit sexual description in text generation; “fade‑to‑black” when scenes would cross that line.

---

## 0) Design Tenets
- **Personality matters.** NPC traits meaningfully change pacing (some are impulsive or casual, some jealous or avoidant).  
- **Context bends rules.** Grief, adrenaline, alcohol, victories, and humiliations create short **Chaos Windows** that can speed or derail intimacy.  
- **Negative can be attractive.** Rivalry and arguments can spark chemistry for certain profiles.  
- **Consequences stick.** Jealousy, rumors, and awkward aftermaths ripple into Plot and Downtime.  
- **Delta‑only.** All relationship changes are session deltas, never edits to baseline NPC files during Play.

---

## 1) NPC Social Profile (Trait Schema)
Backed by `development/data/relationship_traits.json`.

```json
{
  "npc_id": "n_amelie",
  "orientation": "bi|hetero|homo|ace|demi",
  "attraction_to_pc": 0-100,
  "style": "bold|dry|sweet|teasing|brutal_honesty",
  "attachment": "secure|anxious|avoidant|fearful",
  "impulsive": 0-100,
  "drama_affinity": 0-100,
  "casual_ok": true,
  "jealousy": 0-100,
  "poly_ok": false,
  "boundaries": {
    "hard_no": ["topic_or_behavior_keys"],
    "soft_limits": ["keys"]
  },
  "texting": {
    "cadence": "daily|often|rare",
    "emoji": "low|med|high",
    "after_midnight_rule": "never|sometimes|often"
  },
  "reputation_risk_tolerance": 0-100,
  "vulnerability_hooks": ["grief_recent","post_combat_adrenaline","tipsy","lonely_week"]
}
```

> **Tip:** Fill only what matters; unspecified fields default to moderate values.

---

## 2) Relationship States (Finite Set)
Backed by `development/data/relationship_transitions.json`.

- `stranger` → `acquaintance` → `friendly` → `crush` → `dating_casual` → `exclusive`  
- Side states: `hookup_only`, `messy`, `ex`, `blocked`

**Flags:** `intimacy_flag`, `sext_ok`, `jealousy_hot`, `on_break`

**Transitions** depend on **score**, **traits**, and **recent beats** (e.g., memorial, argument, rescue).

---

## 3) Gates, Cooldowns, and Chaos Windows
Base intimacy gates extend **date_hooks.json**. Runtime = `base_threshold` − **trait modifiers** − **context modifiers**.

**Trait Modifiers (examples):**
- `impulsive`: lowers kiss/sext/sleep thresholds by 10–20.  
- `casual_ok`: lowers sext/sleep thresholds; allows `hookup_only` entry.  
- `poly_ok`: lowers jealousy hit; opens triad/quads arcs.  
- `drama_affinity`: raises chance that arguments open **Chaos Windows**.

**Context Modifiers (examples):**
- `grief_recent` (memorial or loss): ± depending on person; many seek warmth: −10 to thresholds.  
- `post_combat_adrenaline`: −10 to kiss/sleep; +rumor risk.  
- `tipsy`: −5 to −15, raises regret chance.  
- `public_scene`: +10 to thresholds (performance anxiety), +jealousy risk.

**Cooldowns:** configurable in `messaging_rules.json` (e.g., 1–3 days between big escalations unless Chaos Window).

---

## 4) Negative‑Attraction Mechanics
Some people are drawn to heat.

**Trigger:** recent **argument** or **rivalry_high** AND `drama_affinity` ≥ 60.  
**Check:** roll vs `(50 − drama_affinity/2 + jealousy/4)` with situational bonuses (`post_combat_adrenaline`, `tipsy`).  
**On Pass:** open `hookup_only` or fast‑track to **kiss**/**sleepover** (if consent & boundaries allow).  
**Consequences:** raise `jealousy_hot`, create **rumor** beat, and possibly lower `trust` temporarily.

Documented in `attraction_chaos.json`.

---

## 5) Messaging & Sexting Pacing
Backed by `development/data/messaging_rules.json` and `texting_templates.json`.

**Cadence Model:**
- `daily`: morning check‑ins or night DMs; responds within hours.  
- `often`: every 1–2 days; bursts after shared scenes.  
- `rare`: weekly; long thoughtful notes or ghosting risks.

**Message Types:** check‑in, joke/meme, invite, confession, apology, argument, **flirt**, **suggestive**, **aftercare**.  
**Sext Gates:** `sext_ok` flag becomes true when thresholds are met; content remains **non‑explicit** and may “fade‑to‑black”.  
**Escalation Levels:** *playful → suggestive → private* (no explicit description).  
**Safety:** any **no** sets a cooldown and logs **boundary reminder** in notes.

---

## 6) Jealousy & Triangles
- Base jealousy chance in `date_hooks.json` is extended in `jealousy_rules.json`.  
- Amplifiers: `public_display`, `recent_argument`, `unclear_status`, `press_rumor`.  
- Resolvers: *clear talk*, *choose openly*, *embrace poly*, or *go messy* (state becomes `messy`).

---

## 7) Outputs (Deltas)
Write into `_campaigns/<pc>/data/session_XXXX/`:
- `relationships.json` → per‑NPC entries: delta score, state transition, flags toggled.  
- `beats.json` → quotes, texts, arguments, kisses (implied), aftermaths.  
- `notes.md` → boundaries discovered, in‑jokes, apologies owed.

---

## 8) Integration
- **Downtime:** feeds contexts (`bar_music`, `memorial`, `hot_springs`) that open Chaos Windows.  
- **Plot Engine:** jealousy/rumor can trigger **Character Drama** or **Romance** seeds.  
- **Refugee Pool:** promotions change availability and texting cadence.  
- **Military Life:** CAP/Standby banter generates flirt seeds; ceremonies trigger grief windows.

---

## 9) GM Prompts
- *“What do you text at 02:11 you’d never say at noon?”*  
- *“You could apologize—or double down. Which itch do you scratch?”*  
- *“A rumor names you in a triangle. Who do you talk to first?”*

