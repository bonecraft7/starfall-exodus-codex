# Cinematic Intro Pipeline — Always‑On Opener (Final Draft v1)

> **Contract:** Every new campaign begins *in ordinary life*, then the sky breaks, then a survival sprint, then the Kuiper rendezvous with the **Thronebreaker**, then the **Fold**. The PC enters play as a **refugee**, with 2–4 strangers who survived alongside them.

This pipeline gives you **menus, prompts, and JSON tables** that the GM/AI can pull without prep. It integrates with **Downtime**, **Plot Engine**, **Refugee Pool**, and **Military Life**.

---

## 0) Flow Overview
1. **Locale** — Pick (or roll) a mundane setting from `cinematic_intro/locales.json` and run 2–4 minutes of slice‑of‑life.  
2. **Astrophobia Event** — Trigger a sky‑breaker from `cinematic_intro/astrophobia_events.json`. Call **Composure**; log sensory detail.  
3. **Survival Chain ×3** — Generate 3 challenges from `cinematic_intro/survival_challenges.json` (one **hazard**, one **social**, one **tech**). Insert **Refugee #1** on 2, **#2–#4** on 3 using `refugee_selection_rules.json`.  
4. **Extraction Vector** — Pick from `cinematic_intro/extraction_vectors.json` (shuttle/tug/pods/lifter/cruiseliner/…); pay the cost; mark scars/debts.  
5. **Kuiper Rendezvous** — Pull beats from `cinematic_intro/kuiper_rendezvous_beats.json`. Apply Fleet clocks.  
6. **Intake & Assignment** — Use `thronebreaker_intake_prompts.json`. Assign ID, housing, and note **volunteer call** for service.  
7. **Fold Ritual** — Narrate the Eldritch Fold with `fold_ritual.json`. Enter state **fold_recovery**.

Write **deltas only** into `_campaigns/<pc>/data/session_XXXX/` (beats, relationships, notes, etc.).

---

## 1) Locale → Slice‑of‑Life
Locales are fully sketched (vibe + NPC sampler + micro‑conflicts). Examples: **Orbital Mall (Luna)**, **Cruiseliner “Saffron Tide”**, **Concert Dome**, **Night Market**, **Museum Ship ‘Archive Ark’**, **Zero‑G Arcade**.  
Use **three sensory details** and **one petty desire** to anchor the PC before the break.

> JSON: `cinematic_intro/locales.json`

---

## 2) Astrophobia (The Sky Breaks)
Use one cue: a hull like a continent eclipses glass, gravity groans, ring‑ice becomes knives, lights turn arterial red, windows spider under fold‑shock. Ask for **Composure** or equivalent; impose **stress** or **minor injury** on fails; always keep it cinematic, **not graphic**.

> JSON: `cinematic_intro/astrophobia_events.json`

---

## 3) Survival Chain (×3)
Choose or roll **hazard**, **social**, and **tech** challenges. Make each a **clear choice with cost**; let success buy speed/space, mixed results buy time with scars, failure splits the group or takes something.

> JSON: `cinematic_intro/survival_challenges.json`

**Insert Refugees:** During challenge 2 and 3, introduce **2–4 strangers** drawn per `refugee_selection_rules.json` (female‑only per your spec; unknown to PC). Give each a tiny **origin fragment** and a **useful skill**. They are **not** guaranteed love interests; they are people.

---

## 4) Extraction Vectors
Shuttle hot‑launch, service tug, leaking pod, hitch on a mass‑lifter, or a pleasure liner going full burn. Each vector lists **costs**, **complications**, and **who dies buying minutes**.

> JSON: `cinematic_intro/extraction_vectors.json`

---

## 5) Kuiper Rendezvous → Thronebreaker
Run the muster: escorts dying on the rim, rag‑fleet count (1 battleship + ~9 military + 30–80 civilian), registration queue, ID assignment, bunks, first meal, rumor net. Then the *Thronebreaker* speaks, asking for **volunteers**—seed the **Starfighter Corps** angle.

> JSON: `cinematic_intro/kuiper_rendezvous_beats.json`, `cinematic_intro/thronebreaker_intake_prompts.json`

---

## 6) Fold Ritual
Describe the **eldritch engine**: antennas lock, lights strobe in impossible ratios, a litany on every channel, a taste like copper and memory. Then the fleet tears elsewhere. Apply **fold_recovery** and a brief **Downtime Window** if safe.

> JSON: `cinematic_intro/fold_ritual.json`

---

## 7) Squadron Rosters (Missing Slots)
The four main squadrons start **understrength**. Use `military/squadrons_template.json` to show vacancies and call‑sign culture. The PC can be evaluated during intake or first CAP.

---

## 8) Safety & Tone
- Keep it **R‑rated in scale**, not in gore.  
- Respect **boundaries_consent.json** (fade‑to‑black).  
- Violence is cinematic; focus on **sound, light, speed, and loss**.

---

## 9) Logging Reminders
Copy stubs from `development/templates/gm_startup_pack/` into your session folder before you play. Fill them *as you go*. Tie **refugee bonds** and **scars** to later **Plot Engine** seeds.

